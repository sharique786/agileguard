/**
 * AgileGuard — Consolidated Frontend Models
 * ═══════════════════════════════════════════════════════════════════════
 * This is the SINGLE SOURCE OF TRUTH for all TypeScript interfaces.
 * Replace src/app/core/models/index.ts entirely with this file.
 *
 * Fixes "model classes not in line with backend / missing attributes":
 * every field referenced anywhere in components across prior sessions
 * (dashboard, reports, story-form, sprint-report) is now declared here.
 */

// ── Enums (mirror backend enums exactly) ─────────────────────────────────────

export type IssueStatusType =
  | 'TODO' | 'IN_PROGRESS' | 'IN_REVIEW' | 'READY_FOR_QA'
  | 'QA_IN_PROGRESS' | 'READY_FOR_RELEASE' | 'DONE' | 'BLOCKED';

export type SeverityType = 'CRITICAL' | 'ERROR' | 'WARNING';

export type GapTypeType =
  | 'MISSING_DESCRIPTION' | 'MISSING_ACCEPTANCE_CRITERIA' | 'BAD_AC_FORMAT'
  | 'MISSING_STORY_POINTS' | 'MISSING_DEV_SUBTASK' | 'MISSING_QA_SUBTASK'
  | 'NO_EFFORT_LOGGED' | 'AGING_STORY' | 'NO_PR_LINKED'
  // New flags (this update)
  | 'RETURNED_FROM_TESTING' | 'STORY_TOO_LARGE' | 'DUPLICATE_STORY'
  | 'HIGH_IMPLEMENTATION_RISK' | 'LIKELY_TO_SPILL';

// ── Core JIRA models ──────────────────────────────────────────────────────────

export interface SubTask {
  key:    string;
  type:   string;               // "Dev Task" | "QA Task" | etc.
  status: IssueStatusType;
  summary?: string;
}

export interface JiraIssue {
  id?:                   string;
  key:                   string;
  summary:               string;
  description?:          string;
  acceptanceCriteria?:   string;
  status:                IssueStatusType;
  issueType?:            string;
  storyPoints?:          number;
  priority?:             string;
  businessLine?:         string;
  projectKey?:           string;

  // People
  assigneeName?:         string;
  reporterName?:         string;
  reporterAccountId?:    string;

  // Epic linkage
  epicLink?:             string;
  epicName?:             string;

  // Team / Sprint
  teamNames?:            string[];
  sprintId?:             number;
  sprintName?:           string;

  // Classification
  components?:           string[];
  fixVersions?:          string[];
  labels?:               string[];

  // Sub-work
  subTasks?:             SubTask[];
  linkedPullRequests?:   string[];

  // Timing
  statusChangedAt?:      string;   // ISO date
  createdAt?:            string;
  timeSpentMinutes?:     number;

  // Quality (populated when returned from a gap-scan endpoint)
  qualityScore?:         number;
  flagged?:              boolean;
}

// ── Gap detection models ──────────────────────────────────────────────────────

export interface GapFinding {
  issueKey:         string;
  type:             GapTypeType;
  severity:         SeverityType;
  message:          string;
  suggestedAction?: string;
  detectedAt?:      string;
}

export interface GapReport {
  issueKey:             string;
  issueSummary:         string;
  qualityScore:         number;
  flagged:              boolean;
  flagReasons?:         string[];      // NEW — human-readable list of why flagged
  findings:             GapFinding[];
  criticalCount:        number;
  errorCount:           number;
  warningCount:         number;

  // Stuck-stage fields
  status?:              string;
  daysInCurrentStatus?: number;
  stuckStageSeverity?:  string;        // "NONE" | "WARNING" | "CRITICAL"
  stuckStageLabel?:     string;
  statusChangedAt?:     string;

  // NEW flag-specific fields (this update)
  returnedFromTesting?: boolean;       // moved back from QA/UAT/Integration to Dev
  storyTooLarge?:       boolean;       // story points > threshold (e.g. 13)
  duplicateOf?:         string;        // issueKey of the story this duplicates
  highImplementationRisk?: boolean;
  likelyToSpillOver?:   boolean;
}

export interface SprintHealthReport {
  projectKey:        string;
  sprintName:        string;
  overallHealthScore: number;
  totalIssues:       number;
  issuesWithGaps:    number;
  flaggedIssues:     number;
  issueReports:      GapReport[];
}

// ── Sprint report models ──────────────────────────────────────────────────────

export interface FeatureTeam {
  id:           string;
  name:         string;
  projectKey:   string;
  memberCount?: number;
  active?:      boolean;
}

export interface JiraSprint {
  id:          number;
  name:        string;
  state:       'active' | 'closed' | 'future';
  startDate?:  string;
  endDate?:    string;
  goal?:       string;
}

export interface SprintStoryDetail {
  issueKey:      string;
  summary:       string;
  storyPoints?:  number;
  assigneeName?: string;
  epicLink?:     string;
  epicName?:     string;
}

export interface TeamSprintReport {
  featureTeamId:   string;
  featureTeamName: string;
  sprintName?:     string;
  sprintId?:       number;
  sprintState?:    string;
  committedStoryPoints:  number;
  acceptedStoryPoints:   number;
  predictability:        number;
  meetsPredictabilityTarget: boolean;
  completedStories: SprintStoryDetail[];
  spilledStories:   SprintStoryDetail[];
  addedStories?:    SprintStoryDetail[];
  capacityPlanned?: number;
  capacityActual?:  number;
}

export interface PiSprintReport {
  projectKey:              string;
  programmePredictability: number;
  teamReports:             TeamSprintReport[];
}

// ── Workflow models (NEW — powers the Workflows page) ─────────────────────────

export type WorkflowStageStatus = 'done' | 'active' | 'blocked' | 'pending';

export interface WorkflowStage {
  key:     string;             // 'dev' | 'code_review' | 'qa' | 'uat' | 'release'
  label:   string;             // "Development"
  status:  WorkflowStageStatus;
  detail?: string;             // e.g. "2/2 sub-tasks closed"
}

export interface CiCheckResult {
  name:        string;         // GitHub Actions workflow/job name
  conclusion:  'success' | 'failure' | 'pending' | 'skipped' | 'unknown';
  url?:        string;
}

export interface StoryWorkflow {
  issueKey:            string;
  summary:             string;
  status:              IssueStatusType;
  stages:              WorkflowStage[];
  prUrl?:              string;
  prNumber?:           number;
  ciChecks:            CiCheckResult[];
  devSubtaskClosed:    boolean;
  qaSubtaskClosed:     boolean;
  readyForRelease:     boolean;
  blockReasons:        string[];   // why it's NOT ready, if applicable
}

// ── Analytics models (NEW — powers the Analytics page) ────────────────────────

export interface AnalyticsSummary {
  projectKey:              string;
  periodLabel:             string;         // e.g. "Last 3 Sprints"

  avgCycleTimeDays:        number;
  avgLeadTimeDays:         number;
  sprintPredictabilityPct: number;
  deploymentFrequencyPerWeek: number;
  storyRejectionRatePct:   number;
  qaEscapeRatePct:         number;
  reopenPct:               number;
  avgReviewTimeHours:      number;
  teamVelocity:            number;         // avg SP per sprint
  avgStoryAgingDays:       number;

  bottlenecks:             BottleneckEntry[];
  rootCauses:              RootCauseEntry[];
  blockedTrend:            BlockedTrendPoint[];
  velocityTrend:           VelocityTrendPoint[];
}

export interface BottleneckEntry {
  stage:        string;      // e.g. "Code Review"
  avgDays:      number;
  issueCount:   number;
}

export interface RootCauseEntry {
  category:     string;      // e.g. "Unclear Requirements"
  occurrences:  number;
  pctOfTotal:   number;
}

export interface BlockedTrendPoint {
  sprintLabel:  string;
  blockedCount: number;
}

export interface VelocityTrendPoint {
  sprintLabel:  string;
  committed:    number;
  completed:    number;
}

// ── Generic API envelope ───────────────────────────────────────────────────────

export interface ApiResponse<T> {
  success: boolean;
  message?: string;
  data:    T;
}
