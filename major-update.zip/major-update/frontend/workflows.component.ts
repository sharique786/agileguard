import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TokenService } from '../../core/services/token.service';
import { JiraKeyComponent } from '../../shared/components/jira-key.component';
import { StoryWorkflow, ApiResponse } from '../../core/models';

/**
 * Workflows page — visual pipeline of every active-sprint story.
 *
 * Each story is rendered as a horizontal stepper:
 *   Development → Code Review → QA/Testing → Ready for Release
 *
 * "Ready for Release" only lights up GREEN when BOTH gates pass:
 *   1. No failing GitHub Actions / CI checks on the linked PR
 *   2. Development AND Testing sub-tasks both exist and are closed
 * Otherwise the stage renders RED/blocked with explicit reasons listed.
 */
@Component({
  selector: 'app-workflows',
  standalone: true,
  imports: [CommonModule, JiraKeyComponent],
  template: `
  <div>
    <div class="page-header mb-16">
      <h1 class="page-title">🔀 Workflows</h1>
      <p class="page-subtitle">
        <span *ngIf="projectKey()" class="project-key-chip">{{ projectKey() }}</span>
        Visual pipeline &amp; release-readiness for every active-sprint story
      </p>
    </div>

    <div *ngIf="!projectKey()" class="empty-state">
      Configure your project key on the Dashboard first.
    </div>

    <div *ngIf="loading()" class="loading-card">
      <div class="spinner" style="width:32px;height:32px;margin:0 auto 12px"></div>
      Loading workflows…
    </div>

    <div *ngIf="!loading()" class="workflow-list">
      <div *ngFor="let wf of workflows()" class="workflow-card">

        <div class="wf-header">
          <app-jira-key [issueKey]="wf.issueKey" [label]="wf.summary" />
          <span class="wf-summary">{{ wf.summary }}</span>
          <span class="wf-readiness"
                [class.wf-ready]="wf.readyForRelease"
                [class.wf-blocked]="!wf.readyForRelease">
            {{ wf.readyForRelease ? '✅ Ready for Release' : '⛔ Not Ready' }}
          </span>
        </div>

        <!-- Horizontal stepper -->
        <div class="wf-stepper">
          <ng-container *ngFor="let stage of wf.stages; let last = last">
            <div class="wf-step" [ngClass]="'wf-step-' + stage.status">
              <div class="wf-step-dot">
                <span *ngIf="stage.status === 'done'">✓</span>
                <span *ngIf="stage.status === 'blocked'">✕</span>
              </div>
              <div class="wf-step-label">{{ stage.label }}</div>
              <div class="wf-step-detail">{{ stage.detail }}</div>
            </div>
            <div *ngIf="!last" class="wf-connector"
                 [ngClass]="'wf-connector-' + stage.status"></div>
          </ng-container>
        </div>

        <!-- CI checks -->
        <div class="wf-ci-row">
          <span class="wf-ci-label">CI Checks:</span>
          <span *ngFor="let c of wf.ciChecks" class="wf-ci-pill"
                [ngClass]="'wf-ci-' + c.conclusion">
            {{ ciIcon(c.conclusion) }} {{ c.name }}
          </span>
          <a *ngIf="wf.prUrl" [href]="wf.prUrl" target="_blank" class="wf-pr-link">View PR ↗</a>
        </div>

        <!-- Block reasons -->
        <div *ngIf="!wf.readyForRelease" class="wf-block-reasons">
          <div class="wf-block-title">⛔ Blocked because:</div>
          <ul>
            <li *ngFor="let reason of wf.blockReasons">{{ reason }}</li>
          </ul>
        </div>
      </div>

      <div *ngIf="workflows().length === 0" class="empty-state">
        No active-sprint stories found.
      </div>
    </div>
  </div>
  `,
  styles: [`
    .project-key-chip {
      display:inline-block; font-family:monospace; font-weight:800; font-size:12px;
      color:var(--teal); background:var(--teal-pale); border:1px solid #BEE0DE;
      border-radius:5px; padding:1px 8px; margin-right:8px;
    }
    .empty-state, .loading-card {
      text-align:center; padding:48px; color:var(--text-muted);
      background:var(--surface); border:1px dashed var(--border); border-radius:10px;
    }
    .workflow-list { display:flex; flex-direction:column; gap:16px; }
    .workflow-card {
      background:var(--surface); border:1px solid var(--border);
      border-radius:10px; padding:18px 20px;
    }
    .wf-header {
      display:flex; align-items:center; gap:10px; margin-bottom:18px; flex-wrap:wrap;
    }
    .wf-summary { flex:1; font-size:14px; color:var(--text-secondary); min-width:0; }
    .wf-readiness {
      font-size:12px; font-weight:700; padding:4px 12px; border-radius:9999px; white-space:nowrap;
    }
    .wf-ready   { background:#DCFCE7; color:#15803D; }
    .wf-blocked { background:#FEE2E2; color:#991B1B; }

    /* Stepper */
    .wf-stepper { display:flex; align-items:flex-start; margin-bottom:14px; }
    .wf-step { display:flex; flex-direction:column; align-items:center; width:140px; text-align:center; }
    .wf-step-dot {
      width:28px; height:28px; border-radius:50%; display:flex; align-items:center; justify-content:center;
      font-size:14px; font-weight:700; margin-bottom:6px; border:2px solid var(--border);
      background:var(--surface); color:var(--text-muted);
    }
    .wf-step-done .wf-step-dot   { background:#16A34A; border-color:#16A34A; color:#fff; }
    .wf-step-active .wf-step-dot { background:var(--teal); border-color:var(--teal); color:#fff; }
    .wf-step-blocked .wf-step-dot{ background:#DC2626; border-color:#DC2626; color:#fff; }
    .wf-step-label { font-size:12px; font-weight:700; color:var(--text-primary); }
    .wf-step-detail { font-size:10px; color:var(--text-muted); margin-top:2px; }
    .wf-connector {
      flex:1; height:2px; background:var(--border); margin-top:14px;
    }
    .wf-connector-done { background:#16A34A; }
    .wf-connector-blocked { background:#DC2626; }

    /* CI row */
    .wf-ci-row { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin-bottom:8px; }
    .wf-ci-label { font-size:11px; font-weight:700; color:var(--text-muted); }
    .wf-ci-pill {
      font-size:11px; font-weight:600; padding:2px 8px; border-radius:9999px;
    }
    .wf-ci-success { background:#DCFCE7; color:#15803D; }
    .wf-ci-failure { background:#FEE2E2; color:#991B1B; }
    .wf-ci-pending { background:#FEF3C7; color:#92400E; }
    .wf-ci-skipped, .wf-ci-unknown { background:#F1F5F9; color:#64748B; }
    .wf-pr-link { font-size:11px; color:var(--teal); margin-left:auto; }

    .wf-block-reasons {
      background:#FEF2F2; border:1px solid #FCA5A5; border-radius:8px;
      padding:10px 14px; font-size:12px; color:#991B1B;
    }
    .wf-block-title { font-weight:700; margin-bottom:4px; }
    .wf-block-reasons ul { margin:0; padding-left:18px; }
  `]
})
export class WorkflowsComponent implements OnInit {
  private http   = inject(HttpClient);
  private tokens = inject(TokenService);

  loading   = signal(false);
  workflows = signal<StoryWorkflow[]>([]);
  projectKey = () => this.tokens.projectKey();

  ngOnInit(): void {
    if (this.projectKey()) this.load();
  }

  load(): void {
    this.loading.set(true);
    this.http.get<ApiResponse<StoryWorkflow[]>>(
      `/api/jira/projects/${this.projectKey()}/workflows`
    ).subscribe({
      next: r => { this.workflows.set(r.data ?? []); this.loading.set(false); },
      error: () => { this.loading.set(false); this.workflows.set([]); }
    });
  }

  ciIcon(conclusion: string): string {
    return { success: '✅', failure: '❌', pending: '⏳', skipped: '⏭️', unknown: '❔' }[conclusion] ?? '❔';
  }
}
