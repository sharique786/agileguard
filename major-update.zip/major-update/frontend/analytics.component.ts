import { Component, OnInit, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { TokenService } from '../../core/services/token.service';
import { AnalyticsSummary, ApiResponse } from '../../core/models';

/**
 * Analytics page — 13 engineering-health metrics in one dashboard:
 * cycle time, lead time, predictability, deployment frequency,
 * rejection rate, QA escape rate, reopen %, review time, velocity,
 * story aging, bottlenecks, root causes, and blocked-story trends.
 */
@Component({
  selector: 'app-analytics',
  standalone: true,
  imports: [CommonModule],
  template: `
  <div>
    <div class="page-header mb-16">
      <h1 class="page-title">📈 Analytics</h1>
      <p class="page-subtitle">
        <span *ngIf="projectKey()" class="project-key-chip">{{ projectKey() }}</span>
        {{ data()?.periodLabel || 'Engineering health metrics' }}
      </p>
    </div>

    <div *ngIf="!projectKey()" class="empty-state">
      Configure your project key on the Dashboard first.
    </div>

    <div *ngIf="loading()" class="loading-card">
      <div class="spinner" style="width:32px;height:32px;margin:0 auto 12px"></div>
      Computing analytics…
    </div>

    <div *ngIf="!loading() && data() as d">

      <!-- Metric tiles -->
      <div class="metrics-grid mb-24">
        <div class="metric-tile">
          <div class="metric-value">{{ d.avgCycleTimeDays }}<span class="metric-unit">d</span></div>
          <div class="metric-label">Avg Cycle Time</div>
        </div>
        <div class="metric-tile">
          <div class="metric-value">{{ d.avgLeadTimeDays }}<span class="metric-unit">d</span></div>
          <div class="metric-label">Lead Time</div>
        </div>
        <div class="metric-tile" [class.metric-good]="d.sprintPredictabilityPct >= 80">
          <div class="metric-value">{{ d.sprintPredictabilityPct }}<span class="metric-unit">%</span></div>
          <div class="metric-label">Sprint Predictability</div>
        </div>
        <div class="metric-tile">
          <div class="metric-value">{{ d.deploymentFrequencyPerWeek }}<span class="metric-unit">/wk</span></div>
          <div class="metric-label">Deployment Frequency</div>
        </div>
        <div class="metric-tile" [class.metric-bad]="d.storyRejectionRatePct > 10">
          <div class="metric-value">{{ d.storyRejectionRatePct }}<span class="metric-unit">%</span></div>
          <div class="metric-label">Story Rejection Rate</div>
        </div>
        <div class="metric-tile" [class.metric-bad]="d.qaEscapeRatePct > 5">
          <div class="metric-value">{{ d.qaEscapeRatePct }}<span class="metric-unit">%</span></div>
          <div class="metric-label">QA Escape Rate</div>
        </div>
        <div class="metric-tile" [class.metric-bad]="d.reopenPct > 10">
          <div class="metric-value">{{ d.reopenPct }}<span class="metric-unit">%</span></div>
          <div class="metric-label">Reopen %</div>
        </div>
        <div class="metric-tile">
          <div class="metric-value">{{ d.avgReviewTimeHours }}<span class="metric-unit">h</span></div>
          <div class="metric-label">Avg Review Time</div>
        </div>
        <div class="metric-tile">
          <div class="metric-value">{{ d.teamVelocity }}</div>
          <div class="metric-label">Team Velocity (SP)</div>
        </div>
        <div class="metric-tile" [class.metric-bad]="d.avgStoryAgingDays > 5">
          <div class="metric-value">{{ d.avgStoryAgingDays }}<span class="metric-unit">d</span></div>
          <div class="metric-label">Story Aging</div>
        </div>
      </div>

      <div class="two-col">
        <!-- Bottleneck analysis -->
        <div class="panel">
          <div class="panel-title">🚧 Bottleneck Analysis</div>
          <div *ngFor="let b of d.bottlenecks" class="bar-row">
            <span class="bar-label">{{ b.stage }}</span>
            <div class="bar-track">
              <div class="bar-fill" [style.width.%]="barWidth(b.avgDays, maxBottleneck(d))"></div>
            </div>
            <span class="bar-value">{{ b.avgDays }}d · {{ b.issueCount }} stories</span>
          </div>
        </div>

        <!-- Root cause analysis -->
        <div class="panel">
          <div class="panel-title">🔍 Root Cause Analysis</div>
          <div *ngFor="let r of d.rootCauses" class="bar-row">
            <span class="bar-label">{{ r.category }}</span>
            <div class="bar-track">
              <div class="bar-fill bar-fill-alt" [style.width.%]="r.pctOfTotal"></div>
            </div>
            <span class="bar-value">{{ r.pctOfTotal }}% ({{ r.occurrences }})</span>
          </div>
          <div *ngIf="d.rootCauses.length === 0" class="text-muted text-sm">
            No categorized root-cause data yet.
          </div>
        </div>
      </div>

      <div class="two-col mt-16">
        <!-- Blocked story trend -->
        <div class="panel">
          <div class="panel-title">🚫 Blocked Story Trend</div>
          <div class="trend-row" *ngFor="let p of d.blockedTrend">
            <span class="trend-label">{{ p.sprintLabel }}</span>
            <div class="bar-track">
              <div class="bar-fill bar-fill-danger" [style.width.%]="barWidth(p.blockedCount, maxBlocked(d))"></div>
            </div>
            <span class="bar-value">{{ p.blockedCount }}</span>
          </div>
        </div>

        <!-- Velocity trend -->
        <div class="panel">
          <div class="panel-title">🏃 Velocity Trend</div>
          <div class="trend-row" *ngFor="let v of d.velocityTrend">
            <span class="trend-label">{{ v.sprintLabel }}</span>
            <div class="bar-track bar-track-double">
              <div class="bar-fill bar-fill-muted" [style.width.%]="barWidth(v.committed, maxVelocity(d))"></div>
              <div class="bar-fill bar-fill-success" [style.width.%]="barWidth(v.completed, maxVelocity(d))"></div>
            </div>
            <span class="bar-value">{{ v.completed }}/{{ v.committed }}</span>
          </div>
        </div>
      </div>
    </div>
  </div>
  `,
  styles: [`
    .project-key-chip {
      display:inline-block; font-family:monospace; font-weight:800; font-size:12px;
      color:var(--teal); background:var(--teal-pale); border:1px solid #BEE0DE;
      border-radius:5px; padding:1px 8px; margin-right:8px;
    }
    .empty-state, .loading-card {
      text-align:center; padding:48px; color:var(--text-muted);
      background:var(--surface); border:1px dashed var(--border); border-radius:10px;
    }
    .metrics-grid {
      display:grid; grid-template-columns:repeat(auto-fit,minmax(160px,1fr)); gap:14px;
    }
    .metric-tile {
      background:var(--surface); border:1px solid var(--border); border-radius:10px;
      padding:18px; text-align:center;
    }
    .metric-value { font-size:28px; font-weight:800; color:var(--text-primary); }
    .metric-unit  { font-size:14px; font-weight:600; color:var(--text-muted); margin-left:2px; }
    .metric-label { font-size:11px; color:var(--text-muted); margin-top:4px; }
    .metric-good .metric-value { color:#16A34A; }
    .metric-bad  .metric-value { color:#DC2626; }

    .two-col { display:grid; grid-template-columns:1fr 1fr; gap:16px; }
    @media (max-width:900px) { .two-col { grid-template-columns:1fr; } }

    .panel {
      background:var(--surface); border:1px solid var(--border); border-radius:10px; padding:18px;
    }
    .panel-title { font-size:14px; font-weight:700; color:var(--text-primary); margin-bottom:14px; }

    .bar-row, .trend-row {
      display:grid; grid-template-columns:130px 1fr 90px; align-items:center; gap:10px;
      margin-bottom:10px; font-size:12px;
    }
    .bar-label, .trend-label { color:var(--text-secondary); overflow:hidden; text-overflow:ellipsis; white-space:nowrap; }
    .bar-track {
      position:relative; height:8px; background:#E5E7EB; border-radius:9999px; overflow:hidden;
    }
    .bar-track-double { height:8px; }
    .bar-fill { position:absolute; left:0; top:0; height:100%; background:var(--teal); border-radius:9999px; }
    .bar-fill-alt     { background:#7C3AED; }
    .bar-fill-danger  { background:#DC2626; }
    .bar-fill-muted   { background:#CBD5E1; }
    .bar-fill-success { background:#16A34A; }
    .bar-value { font-weight:700; color:var(--text-primary); text-align:right; }
  `]
})
export class AnalyticsComponent implements OnInit {
  private http   = inject(HttpClient);
  private tokens = inject(TokenService);

  loading = signal(false);
  data    = signal<AnalyticsSummary | null>(null);
  projectKey = () => this.tokens.projectKey();

  ngOnInit(): void {
    if (this.projectKey()) this.load();
  }

  load(): void {
    this.loading.set(true);
    this.http.get<ApiResponse<AnalyticsSummary>>(
      `/api/jira/projects/${this.projectKey()}/analytics`
    ).subscribe({
      next: r => { this.data.set(r.data); this.loading.set(false); },
      error: () => { this.loading.set(false); }
    });
  }

  barWidth(value: number, max: number): number {
    return max === 0 ? 0 : Math.min(100, (value / max) * 100);
  }
  maxBottleneck(d: AnalyticsSummary): number {
    return Math.max(...d.bottlenecks.map(b => b.avgDays), 1);
  }
  maxBlocked(d: AnalyticsSummary): number {
    return Math.max(...d.blockedTrend.map(p => p.blockedCount), 1);
  }
  maxVelocity(d: AnalyticsSummary): number {
    return Math.max(...d.velocityTrend.map(v => v.committed), 1);
  }
}
