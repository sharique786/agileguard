# Wiring Workflows + Analytics into the app

## 1. app.routes.ts — add two routes

```ts
{
  path: 'workflows',
  loadComponent: () => import('./features/workflows/workflows.component')
    .then(m => m.WorkflowsComponent),
  canActivate: [authGuard]
},
{
  path: 'analytics',
  loadComponent: () => import('./features/analytics/analytics.component')
    .then(m => m.AnalyticsComponent),
  canActivate: [authGuard]
},
```

## 2. File placement

```
src/app/features/workflows/workflows.component.ts   ← new file
src/app/features/analytics/analytics.component.ts   ← new file
```

## 3. app.component.ts — add sidebar nav items

Insert these two `<a class="nav-item">` entries into the sidebar, between
"Gap Reports" and "Sprint Report" (or wherever fits your IA):

```html
<a class="nav-item" routerLink="/workflows" routerLinkActive="active">
  <span class="nav-icon">🔀</span> Workflows
</a>
<a class="nav-item" routerLink="/analytics" routerLinkActive="active">
  <span class="nav-icon">📈</span> Analytics
</a>
```

## 4. Backend — register the two new controllers/services

Both `WorkflowController`/`WorkflowService` and `AnalyticsController`/
`AnalyticsService` live in `agileguard-jira-service`. No new gateway
routes are needed — they fall under the existing `/api/jira/**` route
which already has `JwtValidation` applied.

## 5. GitHubClientService dependency (Workflows only)

`WorkflowService` calls `gitHubClient.getCheckRunsForPr(prUrl)`. If your
existing `agileguard-github-service` client stub doesn't have this method
yet, add:

```java
public List<CiCheckResult> getCheckRunsForPr(String prUrl) {
    // GET https://api.github.com/repos/{owner}/{repo}/commits/{sha}/check-runs
    // Parse conclusion field per check run into CiCheckResult.Conclusion
}
```

In mock mode (`agileguard.jira.use-mock=true`), `WorkflowService` never
calls this — it uses `mockCiChecks()` instead, so Workflows works out of
the box in local/demo environments.
