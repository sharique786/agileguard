/**
 * ADDITIONS TO reports.component.ts
 * ═══════════════════════════════════════════════════════════════════════
 * 1. Add this badge row into the issue card header, right after the
 *    existing "🚨 Flagged" badge and the stuck-stage badge:
 *
 *    <span *ngFor="let reason of issue.flagReasons" class="flag-reason-pill"
 *          [ngClass]="flagReasonClass(reason)">
 *      {{ flagReasonIcon(reason) }} {{ reason }}
 *    </span>
 *
 * 2. Add these two helper methods to the component class:
 */

flagReasonIcon(reason: string): string {
  const map: Record<string, string> = {
    'Returned from testing':     '↩️',
    'Story too large':           '📏',
    'High implementation risk':  '⚠️',
    'Likely to spill over':      '⏳',
  };
  if (reason.startsWith('Duplicate of')) return '🧬';
  return map[reason] ?? '🚩';
}

flagReasonClass(reason: string): string {
  if (reason.startsWith('Duplicate of')) return 'flag-duplicate';
  const map: Record<string, string> = {
    'Returned from testing':     'flag-returned',
    'Story too large':           'flag-large',
    'High implementation risk':  'flag-risk',
    'Likely to spill over':      'flag-spill',
  };
  return map[reason] ?? 'flag-generic';
}

/**
 * 3. Add this CSS to the styles array:
 */

/*
    .flag-reason-pill {
      display: inline-flex; align-items: center; gap: 4px;
      font-size: 10px; font-weight: 700; padding: 3px 8px;
      border-radius: 9999px; white-space: nowrap; margin-left: 4px;
    }
    .flag-returned  { background: #FEE2E2; color: #991B1B; border: 1px solid #FCA5A5; }
    .flag-large     { background: #FEF3C7; color: #92400E; border: 1px solid #FDE68A; }
    .flag-duplicate { background: #EDE9FE; color: #5B21B6; border: 1px solid #DDD6FE; }
    .flag-risk      { background: #FFE4E6; color: #9F1239; border: 1px solid #FDA4AF; }
    .flag-spill     { background: #E0F2FE; color: #0369A1; border: 1px solid #BAE6FD; }
    .flag-generic   { background: #F1F5F9; color: #475569; border: 1px solid #E2E8F0; }
*/
