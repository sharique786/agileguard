/**
 * ADDITIONS TO StoryGapDetector.java
 * ═══════════════════════════════════════════════════════════════════════
 * Merge these into the existing class:
 *   1. Add the 5 rule blocks below into evaluate(), right after Rule 9
 *      (No PR Linked), before the "Stuck-stage analysis" section.
 *   2. Add the new @Value thresholds near the existing warningDays/criticalDays fields.
 *   3. Add the 5 private helper methods at the bottom of the class.
 *   4. Add the new flag fields to the GapReport.builder() call
 *      (returnedFromTesting, storyTooLarge, duplicateOf, highImplementationRisk, likelyToSpillOver).
 *
 * Requires: StoryGapDetector must now be given access to sibling issues in
 * the same sprint/project for duplicate detection and velocity for spill
 * prediction — see evaluateAll(List<JiraIssue>) overload added below,
 * which the calling service (EpicService / dashboard scan) should use
 * instead of calling evaluate() one issue at a time when duplicate
 * detection or spill prediction matters.
 */

// ── New configurable thresholds (add near existing @Value fields) ───────────

@Value("${agileguard.gap.story-too-large-points:13}")
private int storyTooLargeThreshold;

@Value("${agileguard.gap.duplicate-similarity-threshold:0.82}")
private double duplicateSimilarityThreshold;

@Value("${agileguard.gap.high-risk-keywords:payment,security,auth,encryption,pii,migration,infra,production,gdpr}")
private String highRiskKeywordsCsv;

@Value("${agileguard.gap.spill-risk-days-remaining:2}")
private int spillRiskDaysRemaining;


// ── NEW: batch evaluation entry point (use this from EpicService / scan) ────

/**
 * Evaluates a full list of issues together so cross-issue rules
 * (duplicate detection, spill prediction against sprint velocity) can run.
 * Falls back to evaluate(issue) per-item for issues not requiring context.
 */
public List<GapReport> evaluateAll(List<JiraIssue> sprintIssues) {
    List<GapReport> reports = new ArrayList<>();
    double avgVelocityPerDay = estimateAvgVelocityPerDay(sprintIssues);

    for (JiraIssue issue : sprintIssues) {
        GapReport base = evaluate(issue); // existing 9-rule + stuck-stage evaluation

        // Run the 5 new rules and merge results into the base report
        List<GapFinding> newFindings = new ArrayList<>(base.getFindings());
        int scoreAdjustment = 0;

        boolean returnedFromTesting = checkReturnedFromTesting(issue);
        if (returnedFromTesting) {
            newFindings.add(finding(issue.getKey(), GapType.RETURNED_FROM_TESTING, Severity.ERROR,
                    "Story was moved back to Development from a testing stage.",
                    "Investigate why the fix failed testing; consider adding a regression AC."));
            scoreAdjustment -= 15;
        }

        boolean tooLarge = issue.getStoryPoints() != null && issue.getStoryPoints() > storyTooLargeThreshold;
        if (tooLarge) {
            newFindings.add(finding(issue.getKey(), GapType.STORY_TOO_LARGE, Severity.WARNING,
                    String.format("Story is %d points, exceeding the %d-point threshold.",
                            issue.getStoryPoints(), storyTooLargeThreshold),
                    "Split into smaller, independently deliverable stories."));
            scoreAdjustment -= 10;
        }

        String duplicateOf = findDuplicate(issue, sprintIssues);
        if (duplicateOf != null) {
            newFindings.add(finding(issue.getKey(), GapType.DUPLICATE_STORY, Severity.WARNING,
                    "Story appears to duplicate " + duplicateOf + ".",
                    "Confirm with the reporter; close one as a duplicate if confirmed."));
            scoreAdjustment -= 10;
        }

        boolean highRisk = checkHighImplementationRisk(issue);
        if (highRisk) {
            newFindings.add(finding(issue.getKey(), GapType.HIGH_IMPLEMENTATION_RISK, Severity.WARNING,
                    "Story touches a high-risk area (security/payments/data/infra) or lacks a design review.",
                    "Require a design/security review before implementation begins."));
            scoreAdjustment -= 10;
        }

        boolean likelySpill = checkLikelyToSpill(issue, avgVelocityPerDay);
        if (likelySpill) {
            newFindings.add(finding(issue.getKey(), GapType.LIKELY_TO_SPILL, Severity.WARNING,
                    "At current team velocity, this story is unlikely to complete before sprint end.",
                    "Consider descoping, reassigning, or moving to next sprint now."));
            scoreAdjustment -= 10;
        }

        int newScore = Math.max(0, base.getQualityScore() + scoreAdjustment);
        boolean flagged = base.isFlagged() || returnedFromTesting || tooLarge
                || duplicateOf != null || highRisk || likelySpill;

        List<String> flagReasons = new ArrayList<>();
        if (base.isFlagged())        flagReasons.add("Quality score below threshold");
        if (returnedFromTesting)     flagReasons.add("Returned from testing");
        if (tooLarge)                flagReasons.add("Story too large");
        if (duplicateOf != null)     flagReasons.add("Duplicate of " + duplicateOf);
        if (highRisk)                flagReasons.add("High implementation risk");
        if (likelySpill)             flagReasons.add("Likely to spill over");

        reports.add(base.toBuilder()
                .qualityScore(newScore)
                .flagged(flagged)
                .flagReasons(flagReasons)
                .findings(newFindings)
                .returnedFromTesting(returnedFromTesting)
                .storyTooLarge(tooLarge)
                .duplicateOf(duplicateOf)
                .highImplementationRisk(highRisk)
                .likelyToSpillOver(likelySpill)
                .build());
    }
    return reports;
}


// ── NEW: private rule helpers ────────────────────────────────────────────────

/**
 * Rule: Returned From Testing.
 * True when the issue's changelog shows a transition FROM a testing status
 * (Ready for QA / In Testing / UAT) BACK TO a development status
 * (In Progress / To Do), and the current status is development-side again.
 *
 * NOTE: requires JIRA changelog data (expand=changelog on the /search call).
 * If changelog isn't available, this falls back to false (no false positives).
 */
private boolean checkReturnedFromTesting(JiraIssue issue) {
    if (issue.getStatusHistory() == null || issue.getStatusHistory().isEmpty()) {
        return false;
    }
    List<String> testingStatuses = List.of("READY_FOR_QA", "QA_IN_PROGRESS", "UAT", "INTEGRATION_TESTING");
    List<String> devStatuses     = List.of("TODO", "IN_PROGRESS");

    var history = issue.getStatusHistory(); // List<StatusTransition{from,to,at}>
    for (int i = 1; i < history.size(); i++) {
        String prevStatus = history.get(i - 1).getStatus();
        String currStatus = history.get(i).getStatus();
        if (testingStatuses.contains(prevStatus) && devStatuses.contains(currStatus)) {
            return true;
        }
    }
    return false;
}

/**
 * Rule: Duplicate Story.
 * Compares this issue's summary against every other issue in the same
 * sprint using Jaccard token similarity. Returns the matched issue key
 * if similarity exceeds the configured threshold, else null.
 */
private String findDuplicate(JiraIssue issue, List<JiraIssue> allIssues) {
    if (issue.getSummary() == null) return null;
    Set<String> tokensA = tokenize(issue.getSummary());
    if (tokensA.isEmpty()) return null;

    for (JiraIssue other : allIssues) {
        if (other.getKey().equals(issue.getKey())) continue;
        if (other.getSummary() == null) continue;
        Set<String> tokensB = tokenize(other.getSummary());
        double similarity = jaccardSimilarity(tokensA, tokensB);
        if (similarity >= duplicateSimilarityThreshold) {
            return other.getKey();
        }
    }
    return null;
}

private Set<String> tokenize(String text) {
    return Arrays.stream(text.toLowerCase().split("\\W+"))
            .filter(t -> t.length() > 2)
            .collect(Collectors.toSet());
}

private double jaccardSimilarity(Set<String> a, Set<String> b) {
    Set<String> intersection = new HashSet<>(a);
    intersection.retainAll(b);
    Set<String> union = new HashSet<>(a);
    union.addAll(b);
    return union.isEmpty() ? 0 : (double) intersection.size() / union.size();
}

/**
 * Rule: High Implementation Risk.
 * Flags stories whose summary/description/components contain high-risk
 * keywords (security, payments, PII, migration, infra) AND that have no
 * linked design-review confluence page or "design-reviewed" label.
 */
private boolean checkHighImplementationRisk(JiraIssue issue) {
    String haystack = ((issue.getSummary() != null ? issue.getSummary() : "") + " " +
                        (issue.getDescription() != null ? issue.getDescription() : "") + " " +
                        String.join(" ", Optional.ofNullable(issue.getComponents()).orElse(List.of())))
                       .toLowerCase();

    boolean touchesRiskArea = Arrays.stream(highRiskKeywordsCsv.split(","))
            .map(String::trim).anyMatch(haystack::contains);

    boolean hasDesignReview = issue.getLabels() != null
            && issue.getLabels().stream().anyMatch(l -> l.equalsIgnoreCase("design-reviewed"));

    return touchesRiskArea && !hasDesignReview;
}

/**
 * Rule: Likely To Spill.
 * Estimates whether the story can realistically finish before sprint end
 * given the team's average velocity (points/day) and days remaining.
 * A story with remaining points that would need more than the available
 * team-day capacity is flagged.
 */
private boolean checkLikelyToSpill(JiraIssue issue, double avgVelocityPerDay) {
    if (issue.getSprintEndDate() == null) return false;
    if (issue.getStoryPoints() == null || issue.getStoryPoints() == 0) return false;
    if ("DONE".equals(String.valueOf(issue.getStatus()))) return false;

    long daysRemaining = java.time.temporal.ChronoUnit.DAYS.between(
            LocalDate.now(), issue.getSprintEndDate());
    if (daysRemaining > spillRiskDaysRemaining) return false; // plenty of time — not yet at risk

    double remainingCapacity = avgVelocityPerDay * Math.max(daysRemaining, 0);
    return issue.getStoryPoints() > remainingCapacity;
}

/** Rough team velocity estimate: completed points / sprint length so far. */
private double estimateAvgVelocityPerDay(List<JiraIssue> sprintIssues) {
    int completedPoints = sprintIssues.stream()
            .filter(i -> "DONE".equals(String.valueOf(i.getStatus())))
            .mapToInt(i -> Optional.ofNullable(i.getStoryPoints()).orElse(0))
            .sum();
    // Assume a 10-working-day sprint as a reasonable default divisor
    return completedPoints / 10.0;
}
