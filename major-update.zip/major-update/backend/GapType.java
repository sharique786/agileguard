package com.agileguard.common.enums;

/**
 * Full list of gap/flag categories AgileGuard can detect on a story.
 * The last 5 values are NEW in this update — see StoryGapDetector for
 * the detection rules that populate them.
 */
public enum GapType {
    MISSING_DESCRIPTION,
    MISSING_ACCEPTANCE_CRITERIA,
    BAD_AC_FORMAT,
    MISSING_STORY_POINTS,
    MISSING_DEV_SUBTASK,
    MISSING_QA_SUBTASK,
    NO_EFFORT_LOGGED,
    AGING_STORY,
    NO_PR_LINKED,

    // ── NEW flag categories ──────────────────────────────────────────────
    /** Story moved backward from a testing stage (QA/UAT/Integration) to Development. */
    RETURNED_FROM_TESTING,
    /** Story points exceed the "too large" threshold (default 13) and should be split. */
    STORY_TOO_LARGE,
    /** Story summary/description closely matches another open story. */
    DUPLICATE_STORY,
    /** Story touches high-risk areas (security, payments, data migration, infra) or has no design review. */
    HIGH_IMPLEMENTATION_RISK,
    /** Based on current velocity + days remaining in sprint, story is unlikely to finish in time. */
    LIKELY_TO_SPILL
}
