package com.agileguard.jira.service;

import com.agileguard.jira.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Computes the visual workflow pipeline for each story and decides
 * release-readiness based on TWO independent gates:
 *
 *   Gate 1 — GitHub Actions / CI status on the linked PR.
 *            If ANY required check has conclusion = "failure", the story
 *            CANNOT be marked "Ready for Release".
 *
 *   Gate 2 — Sub-task completion. Both a "Development" and a "Testing"
 *            sub-task must exist AND be closed (status = DONE) before
 *            the story can be marked "Ready for Release".
 *
 * A story failing either gate is surfaced with explicit blockReasons[]
 * so the Workflows page can explain exactly why it's not releasable.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowService {

    private final JiraClientService jiraClient;
    private final GitHubClientService gitHubClient; // existing service from agileguard-github-service client stub

    @Value("${agileguard.jira.use-mock:true}")
    private boolean useMock;

    private static final List<String> STAGE_ORDER = List.of(
            "TODO", "IN_PROGRESS", "IN_REVIEW", "READY_FOR_QA",
            "QA_IN_PROGRESS", "READY_FOR_RELEASE", "DONE");

    public List<StoryWorkflow> getWorkflowsForProject(String projectKey) {
        List<JiraIssue> issues = jiraClient.searchByJql(
                "project = " + projectKey + " AND sprint in openSprints()");
        return issues.stream().map(this::buildWorkflow).collect(Collectors.toList());
    }

    public StoryWorkflow getWorkflowForIssue(String issueKey) {
        return jiraClient.getIssue(issueKey)
                .map(this::buildWorkflow)
                .orElseThrow(() -> new NoSuchElementException("Issue not found: " + issueKey));
    }

    // ── Core logic ────────────────────────────────────────────────────────────

    private StoryWorkflow buildWorkflow(JiraIssue issue) {
        List<CiCheckResult> ciChecks = fetchCiChecks(issue);
        boolean devClosed = hasClosedSubtaskOfType(issue, "Dev Task", "Development");
        boolean qaClosed  = hasClosedSubtaskOfType(issue, "QA Task", "Testing");

        boolean anyCiFailed = ciChecks.stream().anyMatch(c -> c.getConclusion() == CiCheckResult.Conclusion.FAILURE);

        List<String> blockReasons = new ArrayList<>();
        if (anyCiFailed) {
            blockReasons.add("One or more CI/CD checks failed on the linked pull request.");
        }
        if (!devClosed) {
            blockReasons.add("Development sub-task is missing or not closed.");
        }
        if (!qaClosed) {
            blockReasons.add("Testing sub-task is missing or not closed.");
        }

        boolean readyForRelease = blockReasons.isEmpty();

        List<WorkflowStage> stages = buildStages(issue, devClosed, qaClosed, anyCiFailed, readyForRelease);

        return StoryWorkflow.builder()
                .issueKey(issue.getKey())
                .summary(issue.getSummary())
                .status(issue.getStatus())
                .stages(stages)
                .prUrl(firstPrUrl(issue))
                .ciChecks(ciChecks)
                .devSubtaskClosed(devClosed)
                .qaSubtaskClosed(qaClosed)
                .readyForRelease(readyForRelease)
                .blockReasons(blockReasons)
                .build();
    }

    private List<WorkflowStage> buildStages(JiraIssue issue, boolean devClosed, boolean qaClosed,
                                             boolean ciFailed, boolean readyForRelease) {
        String current = String.valueOf(issue.getStatus());
        int currentIdx = STAGE_ORDER.indexOf(current);

        List<WorkflowStage> stages = new ArrayList<>();
        stages.add(stage("dev", "Development", currentIdx, 1,
                devClosed ? "Dev sub-task closed" : "Dev sub-task pending"));
        stages.add(stage("review", "Code Review", currentIdx, 2,
                ciFailed ? "CI checks failing" : "CI checks passing"));
        stages.add(stage("qa", "QA / Testing", currentIdx, 3,
                qaClosed ? "QA sub-task closed" : "QA sub-task pending"));
        stages.add(stage("release", "Ready for Release", currentIdx, 5,
                readyForRelease ? "All gates passed" : "Blocked — see reasons"));
        // Force release stage to "blocked" visually even if JIRA status says otherwise
        if (!readyForRelease && "READY_FOR_RELEASE".equals(current)) {
            stages.get(3).setStatus(WorkflowStage.Status.BLOCKED);
        }
        return stages;
    }

    private WorkflowStage stage(String key, String label, int currentIdx, int stageIdx, String detail) {
        WorkflowStage.Status status;
        if (currentIdx > stageIdx)      status = WorkflowStage.Status.DONE;
        else if (currentIdx == stageIdx) status = WorkflowStage.Status.ACTIVE;
        else                             status = WorkflowStage.Status.PENDING;
        return WorkflowStage.builder().key(key).label(label).status(status).detail(detail).build();
    }

    private boolean hasClosedSubtaskOfType(JiraIssue issue, String... typeKeywords) {
        if (issue.getSubTasks() == null) return false;
        for (SubTask sub : issue.getSubTasks()) {
            if (sub.getType() == null) continue;
            boolean matchesType = Arrays.stream(typeKeywords)
                    .anyMatch(kw -> sub.getType().toLowerCase().contains(kw.toLowerCase()));
            if (matchesType && "DONE".equals(String.valueOf(sub.getStatus()))) return true;
        }
        return false;
    }

    private String firstPrUrl(JiraIssue issue) {
        return issue.getLinkedPullRequests() != null && !issue.getLinkedPullRequests().isEmpty()
                ? issue.getLinkedPullRequests().get(0) : null;
    }

    /** Fetches GitHub Actions check-run results for the PR linked to this story. */
    private List<CiCheckResult> fetchCiChecks(JiraIssue issue) {
        if (useMock) return mockCiChecks(issue);
        String prUrl = firstPrUrl(issue);
        if (prUrl == null) return List.of();
        try {
            return gitHubClient.getCheckRunsForPr(prUrl);
        } catch (Exception e) {
            log.warn("Failed to fetch CI checks for {}: {}", issue.getKey(), e.getMessage());
            return List.of();
        }
    }

    private List<CiCheckResult> mockCiChecks(JiraIssue issue) {
        // Deterministic mock: every 3rd issue (by key hash) has a failing check
        boolean fail = Math.abs(issue.getKey().hashCode()) % 3 == 0;
        return List.of(
                CiCheckResult.builder().name("build").conclusion(CiCheckResult.Conclusion.SUCCESS).build(),
                CiCheckResult.builder().name("unit-tests")
                        .conclusion(fail ? CiCheckResult.Conclusion.FAILURE : CiCheckResult.Conclusion.SUCCESS)
                        .build(),
                CiCheckResult.builder().name("lint").conclusion(CiCheckResult.Conclusion.SUCCESS).build()
        );
    }
}
