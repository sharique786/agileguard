package com.agileguard.jira.controller;

import com.agileguard.common.dto.ApiResponse;
import com.agileguard.jira.model.StoryWorkflow;
import com.agileguard.jira.service.WorkflowService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * GET /api/jira/projects/{projectKey}/workflows
 *   → visual pipeline + release-readiness for every active-sprint story
 *
 * GET /api/jira/workflows/{issueKey}
 *   → single-story workflow detail
 */
@RestController
@RequestMapping("/api/jira")
@RequiredArgsConstructor
public class WorkflowController {

    private final WorkflowService workflowService;

    @GetMapping("/projects/{projectKey}/workflows")
    public ApiResponse<List<StoryWorkflow>> getWorkflows(@PathVariable String projectKey) {
        List<StoryWorkflow> workflows = workflowService.getWorkflowsForProject(projectKey);
        return ApiResponse.success(workflows.size() + " story workflows", workflows);
    }

    @GetMapping("/workflows/{issueKey}")
    public ApiResponse<StoryWorkflow> getWorkflow(@PathVariable String issueKey) {
        return ApiResponse.success("Workflow for " + issueKey, workflowService.getWorkflowForIssue(issueKey));
    }
}
