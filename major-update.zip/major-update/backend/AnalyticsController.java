package com.agileguard.jira.controller;

import com.agileguard.common.dto.ApiResponse;
import com.agileguard.jira.model.AnalyticsSummary;
import com.agileguard.jira.service.AnalyticsService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

/** GET /api/jira/projects/{projectKey}/analytics → full AnalyticsSummary */
@RestController
@RequestMapping("/api/jira")
@RequiredArgsConstructor
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    @GetMapping("/projects/{projectKey}/analytics")
    public ApiResponse<AnalyticsSummary> getAnalytics(@PathVariable String projectKey) {
        return ApiResponse.success("Analytics computed", analyticsService.getAnalytics(projectKey));
    }
}
