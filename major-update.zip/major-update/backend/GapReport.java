package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/**
 * Quality gap analysis result for a single JIRA story.
 *
 * toBuilder = true is REQUIRED — StoryGapDetector.evaluateAll() uses
 * base.toBuilder() to layer the 5 new flag fields onto the existing
 * 9-rule evaluation without rebuilding the whole object from scratch.
 */
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class GapReport {

    private String issueKey;
    private String issueSummary;
    private int    qualityScore;
    private boolean flagged;

    /** Human-readable reasons this story is flagged, e.g. "Story too large". */
    @Builder.Default
    private List<String> flagReasons = new ArrayList<>();

    @Builder.Default
    private List<GapFinding> findings = new ArrayList<>();
    private int criticalCount;
    private int errorCount;
    private int warningCount;

    // ── Stuck-stage fields ────────────────────────────────────────────────────
    private String status;
    private long daysInCurrentStatus;
    private String stuckStageSeverity;   // "NONE" | "WARNING" | "CRITICAL"
    private String stuckStageLabel;
    private String statusChangedAt;

    // ── NEW flag fields (this update) ─────────────────────────────────────────
    /** Story was moved backward from a testing stage into Development. */
    private boolean returnedFromTesting;
    /** Story points exceed the "too large" threshold. */
    private boolean storyTooLarge;
    /** Issue key of the story this one appears to duplicate, or null. */
    private String duplicateOf;
    /** Touches a high-risk area without a design review. */
    private boolean highImplementationRisk;
    /** Velocity-based prediction that this story won't finish in the sprint. */
    private boolean likelyToSpillOver;

    public boolean isStuck() {
        return "WARNING".equals(stuckStageSeverity) || "CRITICAL".equals(stuckStageSeverity);
    }
}
