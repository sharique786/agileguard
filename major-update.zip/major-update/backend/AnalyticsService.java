package com.agileguard.jira.service;

import com.agileguard.jira.model.*;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Computes the 13 engineering-health metrics for the Analytics page.
 *
 * Real-mode calculations rely on JIRA changelog data (status transition
 * timestamps) which must be fetched with expand=changelog on searches.
 * Where changelog data isn't available in mock mode, representative
 * synthetic numbers are returned so the dashboard is demo-able.
 */
@Service
@RequiredArgsConstructor
public class AnalyticsService {

    private final JiraClientService jiraClient;

    @Value("${agileguard.jira.use-mock:true}")
    private boolean useMock;

    public AnalyticsSummary getAnalytics(String projectKey) {
        if (useMock) return mockAnalytics(projectKey);

        List<JiraIssue> issues = jiraClient.searchByJql(
                "project = " + projectKey + " AND resolved >= -90d");

        return AnalyticsSummary.builder()
                .projectKey(projectKey)
                .periodLabel("Last 90 Days")
                .avgCycleTimeDays(avgCycleTime(issues))
                .avgLeadTimeDays(avgLeadTime(issues))
                .sprintPredictabilityPct(sprintPredictability(issues))
                .deploymentFrequencyPerWeek(deploymentFrequency(issues))
                .storyRejectionRatePct(storyRejectionRate(issues))
                .qaEscapeRatePct(qaEscapeRate(issues))
                .reopenPct(reopenRate(issues))
                .avgReviewTimeHours(avgReviewTime(issues))
                .teamVelocity(teamVelocity(issues))
                .avgStoryAgingDays(avgStoryAging(issues))
                .bottlenecks(computeBottlenecks(issues))
                .rootCauses(computeRootCauses(issues))
                .blockedTrend(computeBlockedTrend(issues))
                .velocityTrend(computeVelocityTrend(issues))
                .build();
    }

    // ── Real calculations (require changelog; simplified here) ──────────────────
    // Each of these assumes JiraIssue carries statusHistory (List<StatusTransition>)
    // populated from the JIRA changelog. See JiraClientService.mapIssue() —
    // extend it to parse `changelog.histories[]` when wiring this to production.

    private double avgCycleTime(List<JiraIssue> issues) {
        return issues.stream()
                .filter(i -> i.getCycleTimeDays() != null)
                .mapToDouble(JiraIssue::getCycleTimeDays)
                .average().orElse(0);
    }

    private double avgLeadTime(List<JiraIssue> issues) {
        return issues.stream()
                .filter(i -> i.getLeadTimeDays() != null)
                .mapToDouble(JiraIssue::getLeadTimeDays)
                .average().orElse(0);
    }

    private double sprintPredictability(List<JiraIssue> issues) {
        int committed = issues.stream().mapToInt(i -> Optional.ofNullable(i.getStoryPoints()).orElse(0)).sum();
        int done = issues.stream().filter(i -> "DONE".equals(String.valueOf(i.getStatus())))
                .mapToInt(i -> Optional.ofNullable(i.getStoryPoints()).orElse(0)).sum();
        return committed == 0 ? 100 : (done * 100.0 / committed);
    }

    private double deploymentFrequency(List<JiraIssue> issues) {
        long releases = issues.stream().filter(i -> i.getFixVersions() != null && !i.getFixVersions().isEmpty()).count();
        return releases / 12.0; // ~12 weeks in 90 days
    }

    private double storyRejectionRate(List<JiraIssue> issues) {
        long rejected = issues.stream().filter(JiraIssue::isRejectedByPo).count();
        return issues.isEmpty() ? 0 : rejected * 100.0 / issues.size();
    }

    private double qaEscapeRate(List<JiraIssue> issues) {
        long escaped = issues.stream().filter(JiraIssue::isProductionDefect).count();
        return issues.isEmpty() ? 0 : escaped * 100.0 / issues.size();
    }

    private double reopenRate(List<JiraIssue> issues) {
        long reopened = issues.stream().filter(i -> i.getReopenCount() != null && i.getReopenCount() > 0).count();
        return issues.isEmpty() ? 0 : reopened * 100.0 / issues.size();
    }

    private double avgReviewTime(List<JiraIssue> issues) {
        return issues.stream()
                .filter(i -> i.getReviewTimeHours() != null)
                .mapToDouble(JiraIssue::getReviewTimeHours)
                .average().orElse(0);
    }

    private double teamVelocity(List<JiraIssue> issues) {
        return issues.stream().filter(i -> "DONE".equals(String.valueOf(i.getStatus())))
                .mapToInt(i -> Optional.ofNullable(i.getStoryPoints()).orElse(0)).sum() / 3.0; // avg over 3 sprints
    }

    private double avgStoryAging(List<JiraIssue> issues) {
        return issues.stream()
                .filter(i -> !"DONE".equals(String.valueOf(i.getStatus())))
                .mapToLong(JiraIssue::getDaysInCurrentStatus)
                .average().orElse(0);
    }

    private List<BottleneckEntry> computeBottlenecks(List<JiraIssue> issues) {
        Map<String, List<Long>> byStage = new LinkedHashMap<>();
        for (JiraIssue i : issues) {
            byStage.computeIfAbsent(String.valueOf(i.getStatus()), k -> new ArrayList<>())
                    .add(i.getDaysInCurrentStatus());
        }
        return byStage.entrySet().stream()
                .map(e -> BottleneckEntry.builder()
                        .stage(e.getKey())
                        .avgDays(e.getValue().stream().mapToLong(Long::longValue).average().orElse(0))
                        .issueCount(e.getValue().size())
                        .build())
                .sorted(Comparator.comparingDouble(BottleneckEntry::getAvgDays).reversed())
                .collect(Collectors.toList());
    }

    private List<RootCauseEntry> computeRootCauses(List<JiraIssue> issues) {
        // Placeholder: real implementation would categorize gap findings/rejection comments
        return List.of();
    }

    private List<BlockedTrendPoint> computeBlockedTrend(List<JiraIssue> issues) {
        return List.of();
    }

    private List<VelocityTrendPoint> computeVelocityTrend(List<JiraIssue> issues) {
        return List.of();
    }

    // ── Mock data (used until changelog wiring is complete) ──────────────────────

    private AnalyticsSummary mockAnalytics(String projectKey) {
        return AnalyticsSummary.builder()
                .projectKey(projectKey)
                .periodLabel("Last 3 Sprints")
                .avgCycleTimeDays(4.2)
                .avgLeadTimeDays(7.8)
                .sprintPredictabilityPct(83)
                .deploymentFrequencyPerWeek(2.4)
                .storyRejectionRatePct(6.5)
                .qaEscapeRatePct(3.1)
                .reopenPct(8.0)
                .avgReviewTimeHours(5.6)
                .teamVelocity(38.5)
                .avgStoryAgingDays(3.1)
                .bottlenecks(List.of(
                        BottleneckEntry.builder().stage("Code Review").avgDays(2.8).issueCount(14).build(),
                        BottleneckEntry.builder().stage("QA / Testing").avgDays(2.1).issueCount(11).build(),
                        BottleneckEntry.builder().stage("In Progress").avgDays(1.6).issueCount(19).build(),
                        BottleneckEntry.builder().stage("Ready for Release").avgDays(1.2).issueCount(6).build()
                ))
                .rootCauses(List.of(
                        RootCauseEntry.builder().category("Unclear Requirements").occurrences(9).pctOfTotal(32).build(),
                        RootCauseEntry.builder().category("Environment Issues").occurrences(6).pctOfTotal(21).build(),
                        RootCauseEntry.builder().category("Scope Creep").occurrences(5).pctOfTotal(18).build(),
                        RootCauseEntry.builder().category("Dependency Delays").occurrences(4).pctOfTotal(14).build(),
                        RootCauseEntry.builder().category("Other").occurrences(4).pctOfTotal(15).build()
                ))
                .blockedTrend(List.of(
                        BlockedTrendPoint.builder().sprintLabel("Sprint 22").blockedCount(5).build(),
                        BlockedTrendPoint.builder().sprintLabel("Sprint 23").blockedCount(3).build(),
                        BlockedTrendPoint.builder().sprintLabel("Sprint 24").blockedCount(7).build()
                ))
                .velocityTrend(List.of(
                        VelocityTrendPoint.builder().sprintLabel("Sprint 22").committed(42).completed(35).build(),
                        VelocityTrendPoint.builder().sprintLabel("Sprint 23").committed(40).completed(38).build(),
                        VelocityTrendPoint.builder().sprintLabel("Sprint 24").committed(45).completed(42).build()
                ))
                .build();
    }
}
