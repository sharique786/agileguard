import { Injectable, signal } from '@angular/core';

/**
 * Stores and retrieves the tenant's JIRA base URL so every component can
 * build browseable JIRA links without making extra API calls.
 *
 * Priority order:
 *   1. Explicitly set via setBaseUrl() (e.g. from admin panel tenant fetch)
 *   2. localStorage key 'ag_jira_base_url' (persisted across sessions)
 *   3. Environment default (configurable via environment.ts)
 *
 * JIRA browse URL format:
 *   {baseUrl}/browse/{issueKey}   e.g. https://acme.atlassian.net/browse/PLAT-101
 */
@Injectable({ providedIn: 'root' })
export class JiraConfigService {

  private readonly STORAGE_KEY = 'ag_jira_base_url';

  /** Reactive signal — components can use this to build links. */
  baseUrl = signal<string>(this.loadUrl());

  /** Sets and persists the JIRA base URL. Call after tenant config is fetched. */
  setBaseUrl(url: string): void {
    if (!url) return;
    const clean = url.replace(/\/$/, ''); // strip trailing slash
    localStorage.setItem(this.STORAGE_KEY, clean);
    this.baseUrl.set(clean);
  }

  /**
   * Builds a full JIRA browse link for any issue key.
   * Returns empty string if baseUrl is not configured (link renders as non-clickable).
   */
  browseUrl(issueKey: string): string {
    const base = this.baseUrl();
    if (!base || !issueKey) return '';
    return `${base}/browse/${issueKey}`;
  }

  /** Returns true if a JIRA base URL has been configured. */
  isConfigured(): boolean {
    return !!this.baseUrl();
  }

  private loadUrl(): string {
    return localStorage.getItem(this.STORAGE_KEY) ?? '';
  }
}
