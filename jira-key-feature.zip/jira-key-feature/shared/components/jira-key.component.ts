import { Component, Input, OnChanges, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { JiraConfigService } from '../../core/services/jira-config.service';

/**
 * Renders a JIRA issue key as a clickable link that opens in a new tab.
 *
 * Behaviour:
 *   - When a JIRA base URL is configured (via JiraConfigService), the key
 *     renders as an <a href="{baseUrl}/browse/{issueKey}" target="_blank">.
 *   - When no URL is configured yet, the key renders as a styled badge
 *     (graceful degradation — never shows a broken link).
 *   - Fully reactive: if JiraConfigService.baseUrl changes after the
 *     component renders (e.g. admin panel loads tenant config), the link
 *     appears automatically without a page reload.
 *
 * Usage:
 *   <app-jira-key [issueKey]="'PLAT-101'" />
 *   <app-jira-key [issueKey]="s.issueKey" [type]="'epic'" />
 *   <app-jira-key [issueKey]="r.issueKey" [label]="r.issueSummary" />
 *
 * Inputs:
 *   issueKey  — the JIRA key to display and link (e.g. "PLAT-101")  [required]
 *   type      — 'issue' (default, blue) | 'epic' (purple)
 *   label     — tooltip shown on hover; defaults to "Open {key} in JIRA"
 *   showIcon  — show the ↗ external-link icon (default: true)
 */
@Component({
  selector: 'app-jira-key',
  standalone: true,
  imports: [CommonModule],
  template: `
    <ng-container *ngIf="url(); else plain">
      <a [href]="url()"
         target="_blank"
         rel="noopener noreferrer"
         class="jira-key-link"
         [class.jira-key-epic]="type === 'epic'"
         [title]="label || 'Open ' + issueKey + ' in JIRA'">
        {{ issueKey }}
        <span *ngIf="showIcon" class="jira-ext-icon" aria-hidden="true">↗</span>
      </a>
    </ng-container>

    <ng-template #plain>
      <span class="jira-key-plain"
            [class.jira-key-epic]="type === 'epic'"
            [title]="label || issueKey">
        {{ issueKey }}
      </span>
    </ng-template>
  `,
  styles: [`
    :host { display:inline-flex; align-items:center; }

    /* Shared base — both link and plain use identical sizing and shape */
    .jira-key-link, .jira-key-plain {
      display: inline-flex;
      align-items: center;
      gap: 3px;
      font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
      font-size: 12px;
      font-weight: 700;
      padding: 2px 7px;
      border-radius: 4px;
      white-space: nowrap;
      text-decoration: none;
      background: #e0f2fe;
      color: #0369a1;
      border: 1px solid #bae6fd;
      transition: background 0.15s, color 0.15s, border-color 0.15s;
    }

    /* Issue type — blue hover */
    .jira-key-link:hover {
      background: #0369a1;
      color: #ffffff;
      border-color: #0369a1;
    }

    /* Epic type — purple */
    .jira-key-link.jira-key-epic,
    .jira-key-plain.jira-key-epic {
      background: #ede9fe;
      color: #5b21b6;
      border-color: #ddd6fe;
    }
    .jira-key-link.jira-key-epic:hover {
      background: #5b21b6;
      color: #ffffff;
      border-color: #5b21b6;
    }

    /* External link arrow */
    .jira-ext-icon {
      font-size: 10px;
      opacity: 0.7;
      font-style: normal;
      font-family: system-ui, sans-serif;
      line-height: 1;
    }
    .jira-key-link:hover .jira-ext-icon { opacity: 1; }

    /* Plain non-clickable badge */
    .jira-key-plain { cursor: default; }
  `]
})
export class JiraKeyComponent implements OnChanges {
  @Input({ required: true }) issueKey!: string;
  @Input() type: 'issue' | 'epic' = 'issue';
  @Input() label = '';
  @Input() showIcon = true;

  private jiraConfig = inject(JiraConfigService);

  /**
   * Reactive computed signal — re-evaluates whenever either:
   *   (a) the @Input issueKey changes (handled via ngOnChanges updating _issueKey)
   *   (b) JiraConfigService.baseUrl signal changes (e.g. admin panel loads tenant)
   *
   * Returns the full browse URL, or empty string if base URL not yet configured.
   */
  private _issueKey = this.jiraConfig.baseUrl; // prime the computed dependency graph

  url = computed(() => {
    const base = this.jiraConfig.baseUrl();
    if (!base || !this.issueKey) return '';
    return `${base}/browse/${this.issueKey}`;
  });

  /**
   * ngOnChanges fires when the @Input issueKey binding changes at runtime
   * (e.g. parent component iterates over different stories).
   * The computed() above re-reads issueKey from `this.issueKey` directly
   * so Angular change detection handles re-evaluation automatically.
   */
  ngOnChanges(): void {
    // No explicit action needed — computed() re-evaluates on every change
    // detection cycle when its tracked signals change (baseUrl signal).
    // The issueKey @Input is read synchronously from this.issueKey inside
    // the computed, so parent binding changes are picked up automatically.
  }
}
