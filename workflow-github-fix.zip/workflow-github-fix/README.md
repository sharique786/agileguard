# Workflow ↔ GitHub Integration — Corrected Architecture

## What was wrong (two attempts, two different bugs)

1. **First version**: `WorkflowService` (in `jira-service`) injected
   `GitHubClientService` directly as a Spring bean. That class lives in
   `agileguard-github-service` — a *separately deployed* microservice.
   Spring cannot autowire a bean across two different JARs/processes.
   Would not compile.

2. **My first fix attempt**: `WorkflowService` called GitHub's public API
   (`api.github.com`) directly from `jira-service`. This "worked" but
   defeated the purpose of having `github-service` as its own module —
   GitHub token management, rate-limiting, and API version handling would
   now be duplicated in two places.

## Correct architecture (this delivery)

```
┌─────────────────┐   GET /api/github/checks?prUrl=...   ┌──────────────────────┐   GET api.github.com   ┌────────┐
│  jira-service    │ ─────────────────────────────────►  │  github-service       │ ─────────────────────► │ GitHub │
│  WorkflowService │ ◄─────────────────────────────────  │  GitHubChecksController│ ◄───────────────────── │  API   │
└─────────────────┘        JSON: List<CheckRunResult>     └──────────────────────┘                         └────────┘
```

`jira-service` has **zero** compile-time dependency on `github-service` —
Maven-wise they remain completely separate modules. The only coupling is
an HTTP contract (`GET /api/github/checks?prUrl=`), the same relationship
`jira-service` already has with the real JIRA REST API.

## Files in this delivery

| File | Module | Action |
|---|---|---|
| `GitHubChecksController.java` | `agileguard-github-service` | NEW — exposes `/api/github/checks` |
| `CheckRunResult.java` | `agileguard-github-service` | NEW — response model, owned by github-service |
| `GitHubClientService.additions.java` | `agileguard-github-service` | MERGE — add `getCheckRunsForPr()` method to your **existing** `GitHubClientService` class (do not create a new class) |
| `WorkflowService.java` | `agileguard-jira-service` | REPLACE — now calls github-service over REST instead of GitHub directly or via illegal injection |

## Gateway routing

`/api/github/checks` falls under the existing `/api/github/**` route in
`agileguard-gateway/application.yml`, which already has `JwtValidation`
applied — no new gateway route needed.

## application.yml additions (jira-service)

```yaml
agileguard:
  github-service:
    base-url: ${GITHUB_SERVICE_URL:http://localhost:8084}
    # In Kubernetes, replace with the service DNS name, e.g.:
    # base-url: http://agileguard-github-service:8084
```

## application.yml additions (github-service) — only if not already present

```yaml
agileguard:
  github:
    token: ${GITHUB_TOKEN:}
  jira:
    use-mock: true   # reuse whatever mock flag convention github-service already uses
```

## Why the internal call goes to github-service directly, not through the gateway

Service-to-service calls (jira-service → github-service) bypass the
public API Gateway and its JWT validation — that gateway is for
browser-facing traffic only. Internal calls use the service's direct
address (`localhost:8084` locally, Kubernetes service DNS in
production). This matches how `JiraClientService` already calls the
real JIRA API directly rather than through AgileGuard's own gateway.
