package com.agileguard.github.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * A single GitHub Actions check-run result.
 *
 * This class lives in agileguard-github-service (the module that owns
 * GitHub integration). jira-service does NOT have its own copy of this
 * class — it receives these as plain JSON over the REST call to
 * GitHubChecksController and deserializes into its own lightweight DTO
 * (see CiCheckResult in jira-service, which mirrors this shape).
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CheckRunResult {
    private String name;
    private String conclusion;   // "success" | "failure" | "pending" | "skipped" | "unknown" — raw string, jira-service maps to its own enum
    private String url;
}
