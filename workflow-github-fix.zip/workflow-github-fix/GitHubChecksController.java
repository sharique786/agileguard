package com.agileguard.github.controller;

import com.agileguard.common.dto.ApiResponse;
import com.agileguard.github.model.CheckRunResult;
import com.agileguard.github.service.GitHubClientService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Exposes GitHub Actions check-run status for a given pull request.
 *
 * This is the ONLY place in the entire platform that talks to GitHub's
 * REST API for CI check data. Other microservices (jira-service) call
 * THIS endpoint over HTTP — they never call api.github.com directly.
 * That keeps the GitHub token, rate-limit handling, and API version
 * concerns owned by a single service, which is the whole point of
 * splitting AgileGuard into microservices in the first place.
 *
 * GET /api/github/checks?prUrl=https://github.com/{owner}/{repo}/pull/{number}
 */
@RestController
@RequestMapping("/api/github")
@RequiredArgsConstructor
public class GitHubChecksController {

    private final GitHubClientService gitHubClientService;

    @GetMapping("/checks")
    public ApiResponse<List<CheckRunResult>> getChecksForPr(@RequestParam String prUrl) {
        List<CheckRunResult> checks = gitHubClientService.getCheckRunsForPr(prUrl);
        return ApiResponse.success(checks.size() + " check runs found", checks);
    }
}
