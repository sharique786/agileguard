package com.agileguard.jira.service;

import com.agileguard.jira.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Computes the visual workflow pipeline for each story and decides
 * release-readiness based on TWO independent gates:
 *
 *   Gate 1 — GitHub Actions / CI status on the linked PR.
 *   Gate 2 — Development + Testing sub-tasks both exist and are closed.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * ARCHITECTURE — CORRECTED (this revision)
 * ═══════════════════════════════════════════════════════════════════════
 * jira-service does NOT talk to GitHub, and does NOT inject any class
 * from agileguard-github-service (that's a separately deployed
 * microservice — Spring cannot autowire a bean across two JARs/processes).
 *
 * Instead, CI check data is fetched by calling agileguard-github-service's
 * own REST endpoint:
 *
 *     GET http://agileguard-github-service:8084/api/github/checks?prUrl=...
 *
 * github-service owns the GitHub token, rate-limiting, and API version
 * concerns — jira-service just consumes its output as plain JSON, exactly
 * the same pattern JiraClientService uses to call the real JIRA API.
 *
 * In local/dev, the base URL comes from application.yml
 * (agileguard.github-service.base-url) so it can point at localhost:8084
 * without hardcoding; in Kubernetes it would resolve via service discovery.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowService {

    private final JiraClientService jiraClient;
    private final WebClient.Builder webClientBuilder;

    @Value("${agileguard.jira.use-mock:true}")
    private boolean useMock;

    /** Base URL of agileguard-github-service, e.g. http://localhost:8084 (via gateway in prod). */
    @Value("${agileguard.github-service.base-url:http://localhost:8084}")
    private String githubServiceBaseUrl;

    private static final List<String> STAGE_ORDER = List.of(
            "TODO", "IN_PROGRESS", "IN_REVIEW", "READY_FOR_QA",
            "QA_IN_PROGRESS", "READY_FOR_RELEASE", "DONE");

    public List<StoryWorkflow> getWorkflowsForProject(String projectKey) {
        List<JiraIssue> issues = jiraClient.searchByJql(
                "project = " + projectKey + " AND sprint in openSprints()");
        return issues.stream().map(this::buildWorkflow).collect(Collectors.toList());
    }

    public StoryWorkflow getWorkflowForIssue(String issueKey) {
        return jiraClient.getIssue(issueKey)
                .map(this::buildWorkflow)
                .orElseThrow(() -> new NoSuchElementException("Issue not found: " + issueKey));
    }

    // ── Core logic ────────────────────────────────────────────────────────────

    private StoryWorkflow buildWorkflow(JiraIssue issue) {
        List<CiCheckResult> ciChecks = fetchCiChecks(issue);
        boolean devClosed = hasClosedSubtaskOfType(issue, "Dev Task", "Development");
        boolean qaClosed  = hasClosedSubtaskOfType(issue, "QA Task", "Testing");

        boolean anyCiFailed = ciChecks.stream()
                .anyMatch(c -> c.getConclusion() == CiCheckResult.Conclusion.FAILURE);

        List<String> blockReasons = new ArrayList<>();
        if (anyCiFailed) blockReasons.add("One or more CI/CD checks failed on the linked pull request.");
        if (!devClosed)  blockReasons.add("Development sub-task is missing or not closed.");
        if (!qaClosed)   blockReasons.add("Testing sub-task is missing or not closed.");

        boolean readyForRelease = blockReasons.isEmpty();
        List<WorkflowStage> stages = buildStages(issue, devClosed, qaClosed, anyCiFailed, readyForRelease);

        return StoryWorkflow.builder()
                .issueKey(issue.getKey())
                .summary(issue.getSummary())
                .status(issue.getStatus())
                .stages(stages)
                .prUrl(firstPrUrl(issue))
                .ciChecks(ciChecks)
                .devSubtaskClosed(devClosed)
                .qaSubtaskClosed(qaClosed)
                .readyForRelease(readyForRelease)
                .blockReasons(blockReasons)
                .build();
    }

    private List<WorkflowStage> buildStages(JiraIssue issue, boolean devClosed, boolean qaClosed,
                                             boolean ciFailed, boolean readyForRelease) {
        String current = String.valueOf(issue.getStatus());
        int currentIdx = STAGE_ORDER.indexOf(current);

        List<WorkflowStage> stages = new ArrayList<>();
        stages.add(stage("dev", "Development", currentIdx, 1,
                devClosed ? "Dev sub-task closed" : "Dev sub-task pending"));
        stages.add(stage("review", "Code Review", currentIdx, 2,
                ciFailed ? "CI checks failing" : "CI checks passing"));
        stages.add(stage("qa", "QA / Testing", currentIdx, 3,
                qaClosed ? "QA sub-task closed" : "QA sub-task pending"));
        stages.add(stage("release", "Ready for Release", currentIdx, 5,
                readyForRelease ? "All gates passed" : "Blocked — see reasons"));

        // Override JIRA's own status if our gates disagree — the whole point
        // of this feature is not to trust JIRA status alone.
        if (!readyForRelease && "READY_FOR_RELEASE".equals(current)) {
            stages.get(3).setStatus(WorkflowStage.Status.BLOCKED);
        }
        return stages;
    }

    private WorkflowStage stage(String key, String label, int currentIdx, int stageIdx, String detail) {
        WorkflowStage.Status status;
        if (currentIdx > stageIdx)       status = WorkflowStage.Status.DONE;
        else if (currentIdx == stageIdx) status = WorkflowStage.Status.ACTIVE;
        else                              status = WorkflowStage.Status.PENDING;
        return WorkflowStage.builder().key(key).label(label).status(status).detail(detail).build();
    }

    private boolean hasClosedSubtaskOfType(JiraIssue issue, String... typeKeywords) {
        if (issue.getSubTasks() == null) return false;
        for (SubTask sub : issue.getSubTasks()) {
            if (sub.getType() == null) continue;
            boolean matchesType = Arrays.stream(typeKeywords)
                    .anyMatch(kw -> sub.getType().toLowerCase().contains(kw.toLowerCase()));
            if (matchesType && "DONE".equals(String.valueOf(sub.getStatus()))) return true;
        }
        return false;
    }

    private String firstPrUrl(JiraIssue issue) {
        return issue.getLinkedPullRequests() != null && !issue.getLinkedPullRequests().isEmpty()
                ? issue.getLinkedPullRequests().get(0) : null;
    }

    // ── CI checks — fetched via REST call to github-service, NOT GitHub directly ─

    /**
     * Calls agileguard-github-service's GET /api/github/checks?prUrl=...
     * and maps its response (List<Map> with name/conclusion/url as raw
     * JSON, matching github-service's CheckRunResult shape) into this
     * module's own CiCheckResult DTO.
     *
     * jira-service intentionally has NO dependency — Maven or Spring —
     * on anything inside agileguard-github-service. This is a plain HTTP
     * call to another deployable service, the same as any JIRA REST call.
     */
    private List<CiCheckResult> fetchCiChecks(JiraIssue issue) {
        if (useMock) return mockCiChecks(issue);

        String prUrl = firstPrUrl(issue);
        if (prUrl == null) return List.of();

        try {
            List<Map<String, Object>> raw = webClientBuilder.build()
                    .get()
                    .uri(githubServiceBaseUrl + "/api/github/checks?prUrl={prUrl}", prUrl)
                    .retrieve()
                    .bodyToMono(Map.class) // envelope: { success, message, data: [...] }
                    .map(this::extractDataList)
                    .block();

            if (raw == null) return List.of();

            return raw.stream()
                    .map(this::mapCheckRun)
                    .collect(Collectors.toList());

        } catch (Exception e) {
            log.warn("Failed to fetch CI checks from github-service for {} ({}): {}",
                    issue.getKey(), prUrl, e.getMessage());
            return List.of();
        }
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> extractDataList(Map<?, ?> envelope) {
        Object data = envelope.get("data");
        return data instanceof List ? (List<Map<String, Object>>) data : List.of();
    }

    private CiCheckResult mapCheckRun(Map<String, Object> raw) {
        String name = String.valueOf(raw.getOrDefault("name", "unknown"));
        String conclusionStr = String.valueOf(raw.getOrDefault("conclusion", ""));
        String url = raw.get("url") != null ? String.valueOf(raw.get("url")) : null;

        CiCheckResult.Conclusion conclusion = switch (conclusionStr.toLowerCase()) {
            case "success" -> CiCheckResult.Conclusion.SUCCESS;
            case "failure", "timed_out", "cancelled" -> CiCheckResult.Conclusion.FAILURE;
            case "skipped" -> CiCheckResult.Conclusion.SKIPPED;
            case ""        -> CiCheckResult.Conclusion.PENDING;
            default        -> CiCheckResult.Conclusion.UNKNOWN;
        };
        return CiCheckResult.builder().name(name).conclusion(conclusion).url(url).build();
    }

    private List<CiCheckResult> mockCiChecks(JiraIssue issue) {
        boolean fail = Math.abs(issue.getKey().hashCode()) % 3 == 0;
        return List.of(
                CiCheckResult.builder().name("build").conclusion(CiCheckResult.Conclusion.SUCCESS).build(),
                CiCheckResult.builder().name("unit-tests")
                        .conclusion(fail ? CiCheckResult.Conclusion.FAILURE : CiCheckResult.Conclusion.SUCCESS)
                        .build(),
                CiCheckResult.builder().name("lint").conclusion(CiCheckResult.Conclusion.SUCCESS).build()
        );
    }
}
