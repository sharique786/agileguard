/**
 * ADDITION TO agileguard-github-service's EXISTING GitHubClientService.java
 * ═══════════════════════════════════════════════════════════════════════
 * This class already exists in your codebase (per the original project
 * summary: "agileguard-github-service: GitHubClientService, SdlcControlService,
 * LeaderboardService"). Add this ONE method to it — do not create a
 * competing class. If your existing GitHubClientService already has a
 * WebClient/RestTemplate configured for GitHub API calls, reuse that
 * same client/auth setup rather than the standalone one shown here.
 */

// ── Add this method to the existing GitHubClientService class ───────────────

/**
 * Fetches GitHub Actions check-run results for the pull request at prUrl.
 *
 * Flow:
 *   1. Parse owner/repo/PR-number out of the PR URL
 *   2. GET /repos/{owner}/{repo}/pulls/{number} → find head commit SHA
 *   3. GET /repos/{owner}/{repo}/commits/{sha}/check-runs → list of checks
 *
 * Used by: GitHubChecksController (GET /api/github/checks?prUrl=...)
 * which is called by jira-service's WorkflowService over REST.
 */
public List<CheckRunResult> getCheckRunsForPr(String prUrl) {
    if (useMock) {
        return mockCheckRuns(prUrl);
    }

    Matcher m = PR_URL_PATTERN.matcher(prUrl);
    if (!m.find()) {
        log.warn("PR URL doesn't match expected GitHub pattern: {}", prUrl);
        return List.of();
    }
    String owner = m.group(1);
    String repo  = m.group(2);
    String prNum = m.group(3);

    try {
        String prJson = githubWebClient().get()
                .uri("/repos/{owner}/{repo}/pulls/{num}", owner, repo, prNum)
                .retrieve().bodyToMono(String.class).block();
        if (prJson == null) return List.of();

        JsonNode prNode = objectMapper.readTree(prJson);
        String sha = prNode.path("head").path("sha").asText(null);
        if (sha == null) return List.of();

        String checksJson = githubWebClient().get()
                .uri("/repos/{owner}/{repo}/commits/{sha}/check-runs", owner, repo, sha)
                .retrieve().bodyToMono(String.class).block();
        if (checksJson == null) return List.of();

        JsonNode checksRoot = objectMapper.readTree(checksJson);
        JsonNode runs = checksRoot.get("check_runs");
        if (runs == null || !runs.isArray()) return List.of();

        List<CheckRunResult> results = new ArrayList<>();
        for (JsonNode run : runs) {
            results.add(CheckRunResult.builder()
                    .name(run.path("name").asText("unknown"))
                    .conclusion(run.path("conclusion").asText(""))  // "" while still running
                    .url(run.path("html_url").asText(null))
                    .build());
        }
        return results;

    } catch (Exception e) {
        log.warn("Failed to fetch CI checks for PR {}: {}", prUrl, e.getMessage());
        return List.of();
    }
}

// ── Regex + mock helper — add these too if not already present ──────────────

private static final Pattern PR_URL_PATTERN =
        Pattern.compile("github\\.com/([^/]+)/([^/]+)/pull/(\\d+)");

private List<CheckRunResult> mockCheckRuns(String prUrl) {
    // Deterministic mock keyed off the PR URL hash so results are stable per-PR
    boolean fail = Math.abs(prUrl.hashCode()) % 3 == 0;
    return List.of(
            CheckRunResult.builder().name("build").conclusion("success").build(),
            CheckRunResult.builder().name("unit-tests")
                    .conclusion(fail ? "failure" : "success").build(),
            CheckRunResult.builder().name("lint").conclusion("success").build()
    );
}

/**
 * Only add this if GitHubClientService doesn't already have a configured
 * WebClient for GitHub API calls. If it does (likely, since this service
 * already makes GitHub API calls for PR linking / SDLC checks), reuse
 * that existing client/token setup instead of duplicating it here.
 */
private WebClient githubWebClient() {
    return webClientBuilder
            .baseUrl("https://api.github.com")
            .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + githubToken)
            .defaultHeader(HttpHeaders.ACCEPT, "application/vnd.github+json")
            .defaultHeader("X-GitHub-Api-Version", "2022-11-28")
            .build();
}

/*
 * Required imports if not already present in GitHubClientService.java:
 *
 * import com.agileguard.github.model.CheckRunResult;
 * import com.fasterxml.jackson.databind.JsonNode;
 * import com.fasterxml.jackson.databind.ObjectMapper;
 * import org.springframework.http.HttpHeaders;
 * import org.springframework.web.reactive.function.client.WebClient;
 * import java.util.ArrayList;
 * import java.util.List;
 * import java.util.regex.Matcher;
 * import java.util.regex.Pattern;
 */
