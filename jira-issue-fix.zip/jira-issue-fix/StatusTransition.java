package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * A single status transition from JIRA's issue changelog.
 * Populated by JiraClientService.mapIssue() when the /search call is made
 * with expand=changelog (real mode) — see the comment in mapIssue() for
 * the histories[] parsing to add when wiring this to a live JIRA instance.
 *
 * Used by StoryGapDetector.checkReturnedFromTesting() to detect when a
 * story moved backward from a testing status to a development status.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StatusTransition {

    /** The status the issue transitioned FROM, e.g. "READY_FOR_QA". */
    private String status;

    /** Timestamp of this transition. */
    private LocalDateTime at;

    /** Display name of the JIRA status at this point (e.g. "Ready for QA"), optional. */
    private String statusLabel;
}
