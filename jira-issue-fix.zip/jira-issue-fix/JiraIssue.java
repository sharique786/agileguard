package com.agileguard.jira.model;

import com.agileguard.common.enums.IssueStatus;
import com.agileguard.common.enums.IssueType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

/**
 * AgileGuard's internal representation of a JIRA issue/story.
 *
 * ═══════════════════════════════════════════════════════════════════════
 * FIELD PROVENANCE — every field below is traced to a specific consumer.
 * This file is the single authoritative JiraIssue across the whole
 * jira-service module; do not redeclare a competing version elsewhere.
 * ═══════════════════════════════════════════════════════════════════════
 *
 * Core fields          → JiraClientService.mapIssue(), EpicService, StoryGapDetector (original 9 rules)
 * Sub-tasks / PRs       → StoryGapDetector (rules 5/6/9), WorkflowService (release gates)
 * Stuck-stage fields     → StoryGapDetector (aging rule + stuck computation), reports.component.ts
 * statusHistory          → StoryGapDetector.checkReturnedFromTesting() [NEW]
 * sprintStartDate/EndDate→ StoryGapDetector.checkLikelyToSpill() [NEW]
 * cycleTimeDays/leadTimeDays/reopenCount/reviewTimeHours/rejectedByPo/productionDefect
 *                        → AnalyticsService (13-metric calculations) [NEW]
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class JiraIssue {

    // ── Identity ─────────────────────────────────────────────────────────────
    private String id;
    private String key;
    private String projectKey;

    // ── Content ──────────────────────────────────────────────────────────────
    private String summary;
    private String description;
    private String acceptanceCriteria;

    // ── Classification ───────────────────────────────────────────────────────
    private IssueStatus status;
    private IssueType issueType;
    private String priority;
    private String businessLine;

    // ── Estimation / effort ──────────────────────────────────────────────────
    private Integer storyPoints;
    private Long timeSpentMinutes;

    // ── People ───────────────────────────────────────────────────────────────
    private String assigneeName;
    private String assigneeAccountId;
    private String reporterName;
    private String reporterAccountId;

    // ── Epic linkage ─────────────────────────────────────────────────────────
    private String epicLink;
    private String epicName;

    // ── Team / Sprint ─────────────────────────────────────────────────────────
    @Builder.Default
    private List<String> teamNames = new ArrayList<>();
    private Integer sprintId;
    private String sprintName;
    /** Sprint start date — required by StoryGapDetector.checkLikelyToSpill(). */
    private LocalDate sprintStartDate;
    /** Sprint end date — required by StoryGapDetector.checkLikelyToSpill(). */
    private LocalDate sprintEndDate;

    // ── Taxonomy ─────────────────────────────────────────────────────────────
    @Builder.Default
    private List<String> components = new ArrayList<>();
    @Builder.Default
    private List<String> fixVersions = new ArrayList<>();
    @Builder.Default
    private List<String> labels = new ArrayList<>();

    // ── Sub-work ─────────────────────────────────────────────────────────────
    @Builder.Default
    private List<SubTask> subTasks = new ArrayList<>();
    @Builder.Default
    private List<String> linkedPullRequests = new ArrayList<>();

    // ── Status / timing (existing stuck-stage support) ───────────────────────
    /** Date the issue entered its CURRENT status. Used to compute daysInCurrentStatus. */
    private LocalDate statusChangedAt;
    private LocalDate createdAt;

    /**
     * Full changelog of status transitions, oldest first.
     * Required by StoryGapDetector.checkReturnedFromTesting() to detect a
     * QA→Dev backward move. Populated only when JIRA is queried with
     * expand=changelog (real mode); empty list in mock mode / when
     * changelog wasn't requested — consumers must treat empty as "unknown,
     * assume false" rather than erroring.
     */
    @Builder.Default
    private List<StatusTransition> statusHistory = new ArrayList<>();

    // ── Analytics-only fields (populated by AnalyticsService's real-mode path) ─
    /**
     * Days from "In Progress" start to "Done" — cycle time.
     * Null until changelog-derived calculation is wired up; AnalyticsService
     * filters nulls out of the average so partial data doesn't skew results.
     */
    private Double cycleTimeDays;

    /** Days from issue creation to "Done" — lead time. Same null-safety as above. */
    private Double leadTimeDays;

    /** Number of times this issue was reopened after being marked Done. */
    private Integer reopenCount;

    /** Hours the PR sat in code review before merge. */
    private Double reviewTimeHours;

    /** True if Product Owner rejected/declined this story during review. */
    @Builder.Default
    private boolean rejectedByPo = false;

    /** True if a production defect was later linked back to this story. */
    @Builder.Default
    private boolean productionDefect = false;

    // ── Derived helpers (NOT persisted — computed on read) ────────────────────

    /**
     * How many days the issue has been in its current status.
     * Falls back to 0 when statusChangedAt is unknown (never null-unsafe).
     */
    public long getDaysInCurrentStatus() {
        if (statusChangedAt == null) return 0;
        return ChronoUnit.DAYS.between(statusChangedAt, LocalDate.now());
    }

    /** Convenience alias — some callers (Lombok @Data boolean getters) expect isX(). */
    public boolean isRejectedByPo() {
        return rejectedByPo;
    }

    public boolean isProductionDefect() {
        return productionDefect;
    }
}
