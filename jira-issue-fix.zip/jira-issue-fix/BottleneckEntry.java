package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** One row in the Analytics page's Bottleneck Analysis panel. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class BottleneckEntry {
    private String stage;      // e.g. "Code Review"
    private double avgDays;
    private int issueCount;
}
