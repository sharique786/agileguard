package com.agileguard.jira.model;

import com.agileguard.common.enums.IssueStatus;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Visual pipeline + release-readiness verdict for a single JIRA story. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class StoryWorkflow {

    private String issueKey;
    private String summary;
    private IssueStatus status;

    @Builder.Default
    private List<WorkflowStage> stages = new ArrayList<>();

    private String prUrl;
    private Integer prNumber;

    @Builder.Default
    private List<CiCheckResult> ciChecks = new ArrayList<>();

    private boolean devSubtaskClosed;
    private boolean qaSubtaskClosed;
    private boolean readyForRelease;

    @Builder.Default
    private List<String> blockReasons = new ArrayList<>();
}
