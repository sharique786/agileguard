package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** One row in the Analytics page's Root Cause Analysis panel. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class RootCauseEntry {
    private String category;    // e.g. "Unclear Requirements"
    private int occurrences;
    private double pctOfTotal;
}
