package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** One point in the Analytics page's Velocity Trend chart. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class VelocityTrendPoint {
    private String sprintLabel;
    private int committed;
    private int completed;
}
