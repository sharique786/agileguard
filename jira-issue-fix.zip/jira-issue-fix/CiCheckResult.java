package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** A single GitHub Actions / CI check-run result, fetched for the PR linked to a story. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CiCheckResult {

    private String name;          // GitHub Actions job name, e.g. "unit-tests"
    private Conclusion conclusion;
    private String url;

    public enum Conclusion { SUCCESS, FAILURE, PENDING, SKIPPED, UNKNOWN }
}
