# AgileGuard — Cross-Module Consistency Fix

This pass fixed the compile-breaking gaps caused by the last update
(StoryGapDetector, WorkflowService, AnalyticsService) referencing fields
and model classes that never existed. Full "regenerate the entire
project" wasn't attempted — that would mean rewriting ~40 files blind,
with no compiler in this environment to verify it, which is a good way
to introduce new bugs while claiming to fix old ones. Instead: every
field/class actually referenced by the new code was traced back to its
consumer and added, verified by grep cross-reference, not by guessing.

## Files in this delivery

| File | Type | Purpose |
|---|---|---|
| `JiraIssue.java` | REPLACE | Adds `statusHistory`, `sprintStartDate`, `sprintEndDate`, `cycleTimeDays`, `leadTimeDays`, `reopenCount`, `reviewTimeHours`, `rejectedByPo`, `productionDefect` — every field StoryGapDetector/AnalyticsService reference that didn't exist |
| `StatusTransition.java` | NEW | Backs `JiraIssue.statusHistory` |
| `WorkflowStage.java` | NEW | Was referenced by WorkflowService but never created as a Java class (only existed as a TS interface) |
| `CiCheckResult.java` | NEW | Same gap — referenced, never created |
| `StoryWorkflow.java` | NEW | Same gap |
| `BottleneckEntry.java`, `RootCauseEntry.java`, `BlockedTrendPoint.java`, `VelocityTrendPoint.java`, `AnalyticsSummary.java` | NEW | Same gap — AnalyticsService referenced all 5, none existed as Java POJOs |
| `WorkflowService.java` | REPLACE | **Architectural bug fixed**: previous version injected `GitHubClientService` directly, but that class lives in the separate `agileguard-github-service` microservice — Spring cannot autowire a bean across two separately-deployed services. Rewritten to call the GitHub REST API directly via `WebClient`, the same pattern `JiraClientService` uses for JIRA. |

## Required additions to StoryGapDetector.java

The `StoryGapDetector.additions.java` merged in the previous turn needs
these imports added to the top of the file if not already present:

```java
import com.agileguard.jira.model.StatusTransition;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
```

## Required application.yml additions

```yaml
agileguard:
  github:
    token: ${GITHUB_TOKEN:}   # personal access token or GitHub App token
                              # used by WorkflowService for CI check-run lookups
  gap:
    story-too-large-points: 13
    duplicate-similarity-threshold: 0.82
    high-risk-keywords: payment,security,auth,encryption,pii,migration,infra,production,gdpr
    spill-risk-days-remaining: 2
```

## Known limitation — real-mode changelog data

`statusHistory`, `cycleTimeDays`, `leadTimeDays`, `reopenCount`,
`reviewTimeHours` are only populated when `JiraClientService.realSearchByJql()`
requests `expand=changelog` on the JIRA `/search` call and a changelog
parser is added to `mapIssue()`. That parser was NOT part of this fix —
it's a genuinely separate, sizeable piece of work (JIRA's changelog
format needs per-field transition parsing). Until it's added:

- `StoryGapDetector.checkReturnedFromTesting()` safely returns `false`
  (empty `statusHistory` → no false positives)
- `StoryGapDetector.checkLikelyToSpill()` safely returns `false` when
  `sprintEndDate` is null
- `AnalyticsService`'s real-mode path filters out nulls before averaging,
  so cycle/lead time show as `0` until wired rather than crashing

Mock mode (`agileguard.jira.use-mock=true`) is unaffected — all mock
data already includes representative values for demo purposes.

## What "regenerate the entire project bug-free" would actually require

To do this properly rather than superficially, the next step would be:
compile the full `agileguard` Maven multi-module project in this sandbox
end-to-end, fix errors iteratively against the real compiler, and repeat
for the Angular build. That's a bounded, well-defined task I can do —
but it needs the actual current source tree uploaded or restored to
`/home/claude/agileguard` first, since this session's workspace was
reset and no code from prior sessions persists on disk here. If you
upload the current zip of the project, I'll compile it for real and
fix whatever the compiler actually flags, rather than another blind
static-analysis pass.
