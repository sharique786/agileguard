package com.agileguard.jira.service;

import com.agileguard.jira.model.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * Computes the visual workflow pipeline for each story and decides
 * release-readiness based on TWO independent gates:
 *
 *   Gate 1 — GitHub Actions / CI status on the linked PR.
 *            If ANY required check has conclusion = "failure", the story
 *            CANNOT be marked "Ready for Release".
 *
 *   Gate 2 — Sub-task completion. Both a "Development" and a "Testing"
 *            sub-task must exist AND be closed (status = DONE) before
 *            the story can be marked "Ready for Release".
 *
 * ARCHITECTURE NOTE (fixed in this revision):
 * This service previously injected GitHubClientService directly, but that
 * class belongs to the separate agileguard-github-service microservice —
 * Spring cannot autowire a bean from another deployable JAR/service across
 * process boundaries. This service now calls the GitHub REST API directly
 * over HTTP via WebClient, exactly the same pattern JiraClientService uses
 * for JIRA. No cross-module dependency required.
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class WorkflowService {

    private final JiraClientService jiraClient;
    private final ObjectMapper objectMapper = new ObjectMapper();
    private final WebClient.Builder webClientBuilder = WebClient.builder();

    @Value("${agileguard.jira.use-mock:true}")
    private boolean useMock;

    @Value("${agileguard.github.token:}")
    private String githubToken;

    private static final List<String> STAGE_ORDER = List.of(
            "TODO", "IN_PROGRESS", "IN_REVIEW", "READY_FOR_QA",
            "QA_IN_PROGRESS", "READY_FOR_RELEASE", "DONE");

    // Matches PR URLs like https://github.com/{owner}/{repo}/pull/{number}
    private static final Pattern PR_URL_PATTERN =
            Pattern.compile("github\\.com/([^/]+)/([^/]+)/pull/(\\d+)");

    public List<StoryWorkflow> getWorkflowsForProject(String projectKey) {
        List<JiraIssue> issues = jiraClient.searchByJql(
                "project = " + projectKey + " AND sprint in openSprints()");
        return issues.stream().map(this::buildWorkflow).collect(Collectors.toList());
    }

    public StoryWorkflow getWorkflowForIssue(String issueKey) {
        return jiraClient.getIssue(issueKey)
                .map(this::buildWorkflow)
                .orElseThrow(() -> new NoSuchElementException("Issue not found: " + issueKey));
    }

    // ── Core logic ────────────────────────────────────────────────────────────

    private StoryWorkflow buildWorkflow(JiraIssue issue) {
        List<CiCheckResult> ciChecks = fetchCiChecks(issue);
        boolean devClosed = hasClosedSubtaskOfType(issue, "Dev Task", "Development");
        boolean qaClosed  = hasClosedSubtaskOfType(issue, "QA Task", "Testing");

        boolean anyCiFailed = ciChecks.stream()
                .anyMatch(c -> c.getConclusion() == CiCheckResult.Conclusion.FAILURE);

        List<String> blockReasons = new ArrayList<>();
        if (anyCiFailed) {
            blockReasons.add("One or more CI/CD checks failed on the linked pull request.");
        }
        if (!devClosed) {
            blockReasons.add("Development sub-task is missing or not closed.");
        }
        if (!qaClosed) {
            blockReasons.add("Testing sub-task is missing or not closed.");
        }

        boolean readyForRelease = blockReasons.isEmpty();
        List<WorkflowStage> stages = buildStages(issue, devClosed, qaClosed, anyCiFailed, readyForRelease);

        return StoryWorkflow.builder()
                .issueKey(issue.getKey())
                .summary(issue.getSummary())
                .status(issue.getStatus())
                .stages(stages)
                .prUrl(firstPrUrl(issue))
                .ciChecks(ciChecks)
                .devSubtaskClosed(devClosed)
                .qaSubtaskClosed(qaClosed)
                .readyForRelease(readyForRelease)
                .blockReasons(blockReasons)
                .build();
    }

    private List<WorkflowStage> buildStages(JiraIssue issue, boolean devClosed, boolean qaClosed,
                                             boolean ciFailed, boolean readyForRelease) {
        String current = String.valueOf(issue.getStatus());
        int currentIdx = STAGE_ORDER.indexOf(current);

        List<WorkflowStage> stages = new ArrayList<>();
        stages.add(stage("dev", "Development", currentIdx, 1,
                devClosed ? "Dev sub-task closed" : "Dev sub-task pending"));
        stages.add(stage("review", "Code Review", currentIdx, 2,
                ciFailed ? "CI checks failing" : "CI checks passing"));
        stages.add(stage("qa", "QA / Testing", currentIdx, 3,
                qaClosed ? "QA sub-task closed" : "QA sub-task pending"));
        stages.add(stage("release", "Ready for Release", currentIdx, 5,
                readyForRelease ? "All gates passed" : "Blocked — see reasons"));

        // Force the release stage to render as BLOCKED even if JIRA's own
        // status field claims "Ready for Release" but our gates disagree —
        // this is the whole point of the feature: don't trust JIRA status alone.
        if (!readyForRelease && "READY_FOR_RELEASE".equals(current)) {
            stages.get(3).setStatus(WorkflowStage.Status.BLOCKED);
        }
        return stages;
    }

    private WorkflowStage stage(String key, String label, int currentIdx, int stageIdx, String detail) {
        WorkflowStage.Status status;
        if (currentIdx > stageIdx)       status = WorkflowStage.Status.DONE;
        else if (currentIdx == stageIdx) status = WorkflowStage.Status.ACTIVE;
        else                              status = WorkflowStage.Status.PENDING;
        return WorkflowStage.builder().key(key).label(label).status(status).detail(detail).build();
    }

    private boolean hasClosedSubtaskOfType(JiraIssue issue, String... typeKeywords) {
        if (issue.getSubTasks() == null) return false;
        for (SubTask sub : issue.getSubTasks()) {
            if (sub.getType() == null) continue;
            boolean matchesType = Arrays.stream(typeKeywords)
                    .anyMatch(kw -> sub.getType().toLowerCase().contains(kw.toLowerCase()));
            if (matchesType && "DONE".equals(String.valueOf(sub.getStatus()))) return true;
        }
        return false;
    }

    private String firstPrUrl(JiraIssue issue) {
        return issue.getLinkedPullRequests() != null && !issue.getLinkedPullRequests().isEmpty()
                ? issue.getLinkedPullRequests().get(0) : null;
    }

    // ── GitHub Actions check-run fetch (direct HTTP call, no cross-module bean) ──

    private List<CiCheckResult> fetchCiChecks(JiraIssue issue) {
        if (useMock) return mockCiChecks(issue);

        String prUrl = firstPrUrl(issue);
        if (prUrl == null) return List.of();

        Matcher m = PR_URL_PATTERN.matcher(prUrl);
        if (!m.find()) {
            log.warn("PR URL doesn't match expected GitHub pattern: {}", prUrl);
            return List.of();
        }
        String owner = m.group(1);
        String repo  = m.group(2);
        String prNum = m.group(3);

        try {
            // 1. Get the PR to find its head commit SHA
            String prJson = githubClient().get()
                    .uri("/repos/{owner}/{repo}/pulls/{num}", owner, repo, prNum)
                    .retrieve().bodyToMono(String.class).block();
            if (prJson == null) return List.of();
            JsonNode prNode = objectMapper.readTree(prJson);
            String sha = prNode.path("head").path("sha").asText(null);
            if (sha == null) return List.of();

            // 2. Get check-runs for that commit SHA
            String checksJson = githubClient().get()
                    .uri("/repos/{owner}/{repo}/commits/{sha}/check-runs", owner, repo, sha)
                    .retrieve().bodyToMono(String.class).block();
            if (checksJson == null) return List.of();
            JsonNode checksRoot = objectMapper.readTree(checksJson);
            JsonNode runs = checksRoot.get("check_runs");
            if (runs == null || !runs.isArray()) return List.of();

            return StreamSupport.stream(runs.spliterator(), false)
                    .map(this::mapCheckRun)
                    .collect(Collectors.toList());

        } catch (Exception e) {
            log.warn("Failed to fetch CI checks for {} ({}): {}", issue.getKey(), prUrl, e.getMessage());
            return List.of();
        }
    }

    private CiCheckResult mapCheckRun(JsonNode run) {
        String name = run.path("name").asText("unknown");
        String conclusionStr = run.path("conclusion").asText(""); // "" while still running
        CiCheckResult.Conclusion conclusion = switch (conclusionStr.toLowerCase()) {
            case "success"   -> CiCheckResult.Conclusion.SUCCESS;
            case "failure", "timed_out", "cancelled" -> CiCheckResult.Conclusion.FAILURE;
            case "skipped"   -> CiCheckResult.Conclusion.SKIPPED;
            case ""          -> CiCheckResult.Conclusion.PENDING;
            default          -> CiCheckResult.Conclusion.UNKNOWN;
        };
        String url = run.path("html_url").asText(null);
        return CiCheckResult.builder().name(name).conclusion(conclusion).url(url).build();
    }

    private WebClient githubClient() {
        return webClientBuilder
                .baseUrl("https://api.github.com")
                .defaultHeader(HttpHeaders.AUTHORIZATION, "Bearer " + githubToken)
                .defaultHeader(HttpHeaders.ACCEPT, "application/vnd.github+json")
                .defaultHeader("X-GitHub-Api-Version", "2022-11-28")
                .build();
    }

    private List<CiCheckResult> mockCiChecks(JiraIssue issue) {
        // Deterministic mock: every 3rd issue (by key hash) has a failing check
        boolean fail = Math.abs(issue.getKey().hashCode()) % 3 == 0;
        return List.of(
                CiCheckResult.builder().name("build").conclusion(CiCheckResult.Conclusion.SUCCESS).build(),
                CiCheckResult.builder().name("unit-tests")
                        .conclusion(fail ? CiCheckResult.Conclusion.FAILURE : CiCheckResult.Conclusion.SUCCESS)
                        .build(),
                CiCheckResult.builder().name("lint").conclusion(CiCheckResult.Conclusion.SUCCESS).build()
        );
    }
}
