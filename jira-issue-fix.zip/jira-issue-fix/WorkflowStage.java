package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/** A single stage in the Workflows page's visual pipeline (Dev → Review → QA → Release). */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class WorkflowStage {

    private String key;      // "dev" | "review" | "qa" | "release"
    private String label;    // "Development"
    private Status status;
    private String detail;   // e.g. "Dev sub-task closed"

    public enum Status { DONE, ACTIVE, BLOCKED, PENDING }
}
