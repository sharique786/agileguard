package com.agileguard.jira.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

/** Full payload for the Analytics page — all 13 metrics + 4 breakdown lists. */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AnalyticsSummary {

    private String projectKey;
    private String periodLabel;

    private double avgCycleTimeDays;
    private double avgLeadTimeDays;
    private double sprintPredictabilityPct;
    private double deploymentFrequencyPerWeek;
    private double storyRejectionRatePct;
    private double qaEscapeRatePct;
    private double reopenPct;
    private double avgReviewTimeHours;
    private double teamVelocity;
    private double avgStoryAgingDays;

    @Builder.Default
    private List<BottleneckEntry> bottlenecks = new ArrayList<>();
    @Builder.Default
    private List<RootCauseEntry> rootCauses = new ArrayList<>();
    @Builder.Default
    private List<BlockedTrendPoint> blockedTrend = new ArrayList<>();
    @Builder.Default
    private List<VelocityTrendPoint> velocityTrend = new ArrayList<>();
}
